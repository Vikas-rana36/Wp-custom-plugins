<?php



function baby_names_generator($atts) {

global $wpdb;

global $baby_category_table;

global $baby_names_table;

if(!empty($atts)) {

      $gender_att = $atts['gen'];

}



?>



<link type="text/css" rel="stylesheet" href="<?php echo plugins_url(); ?>/baby-name-generator/frontend/name-generator.css?v=<?php echo mt_rand();?>">



<script src="<?php echo plugins_url() ?>/baby-name-generator/frontend/shortcode.js?v=<?php echo mt_rand();?>"></script>



<script>var admin_ajx_url = "<?php echo admin_url('admin-ajax.php'); ?>";</script>



<!-- Search with category -->



<div id='categoryContainer'></div>



<?php



/** Results For Search Form **/



if($_GET['custom_search'] && $_GET['custom_search'] == 'Szukaj' ) {

$SearchString = filter_var($_GET['searchTerm'],FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);

$custom_search = filter_var($_GET['custom_search'],FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);

$gender_search = filter_var($_GET['genderVal'],FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);

if(isset($gender_search) && ($gender_search!='')) {

    $new_search_url = get_permalink().'?searchTerm='.$SearchString.'&genderVal='.$gender_search.'&custom_search='.$custom_search;

    $new_search_url_rm_search = get_permalink().'?searchTerm='.$SearchString.'&custom_search='.$custom_search;

    $all_url = $new_search_url_rm_search.'&all=all';

    $boys_url  = $new_search_url_rm_search.'&boy=boy';

    $girls_url = $new_search_url_rm_search.'&girl=girl';

} else {

    $new_search_url = get_permalink().'?searchTerm='.$SearchString.'&custom_search='.$custom_search;

    $all_url = $new_search_url.'&all=all';

}





 if($gender_att == 'boy') {

      $search_records = get_search_records($SearchString,$gender_att);

    if(strlen($SearchString) == '1') {

        $resultSet = $wpdb->get_results("SELECT DISTINCT `name`,`gender` FROM $baby_names_table WHERE `name` LIKE '".$SearchString."%' AND `gender` = '$gender_att' ORDER BY `name` ASC");

        $rowcountTotal = $wpdb->num_rows;

       // $rowcountTotal = $wpdb->get_var("SELECT COUNT(*) FROM $baby_names_table WHERE `name` LIKE '".$SearchString."%' AND `gender` = '$gender_att' ORDER BY `name` ASC");

    } else {

        $resultSet = $wpdb->get_results("SELECT DISTINCT `name`,`gender` FROM $baby_names_table WHERE `name` LIKE '%".$SearchString."%' AND `gender` = '$gender_att' ORDER BY `name` ASC");

        $rowcountTotal = $wpdb->num_rows;

      //  $rowcountTotal = $wpdb->get_var("SELECT COUNT(*) FROM $baby_names_table WHERE `name` LIKE '%".$SearchString."%' AND `gender` = '$gender_att' ORDER BY `name` ASC");

    }

      $pagination_url = $all_url;

      $gender_hidden_val = $gender_att;

  } elseif($gender_att == 'girl') {

      $search_records = get_search_records($SearchString,$gender_att);

    if(strlen($SearchString) == '1') {

      //  $rowcountTotal = $wpdb->get_var("SELECT COUNT(*) FROM $baby_names_table WHERE `name` LIKE '".$SearchString."%' AND `gender` = '$gender_att' ORDER BY `name` ASC");

        $resultSet = $wpdb->get_results("SELECT DISTINCT `name`,`gender` FROM $baby_names_table WHERE `name` LIKE '".$SearchString."%' AND `gender` = '$gender_att' ORDER BY `name` ASC");

        $rowcountTotal = $wpdb->num_rows;

    } else {

        $resultSet = $wpdb->get_results("SELECT DISTINCT `name`,`gender` FROM $baby_names_table WHERE `name` LIKE '%".$SearchString."%' AND `gender` = '$gender_att' ORDER BY `name` ASC");

        $rowcountTotal = $wpdb->num_rows;

       // $rowcountTotal = $wpdb->get_var("SELECT COUNT(*) FROM $baby_names_table WHERE `name` LIKE '%".$SearchString."%' AND `gender` = '$gender_att' ORDER BY `name` ASC");

    }

      $pagination_url = $all_url;

      $gender_hidden_val = $gender_att;

  }





if(count($search_records) > 0) { ?>

    <div id="baby-name-results-container" class="margin-top-30 search-container">

        <div class="baby-name-tool-title">

            <h1 class="baby-name-tool-title">

            <?php echo "Wyniki wyszukiwania dla - ".$SearchString;?>

            </h1>

        </div>

        <div class="baby-name-list">

            <table class="table">

                <thead>

                    <tr>

                        <th>

                        Nazwa

                        </th>

                        <th>

                        Płeć

                        </th>

                    </tr>

                </thead>

                <tbody>

                    <?php foreach($search_records as $bnames) {  ?>

                        <tr>

                            <td><?php echo $bnames->name; ?></td>

                            <?php if($_GET['boy'] == 'boy') {

                                echo '<td><i class="fa fa-mars fa-2x" aria-hidden="true"></i></td>';

                            } elseif($_GET['girl'] == 'girl') {

                                echo '<td><i class="fa fa-venus fa-2x" aria-hidden="true"></i></td>';

                            } else {

                                if($bnames->gender == 'boy') {

                                    echo '<td><i class="fa fa-mars fa-2x" aria-hidden="true"></i></td>';

                                } elseif($bnames->gender == 'girl') {

                                    echo '<td><i class="fa fa-venus fa-2x" aria-hidden="true"></i></td>';

                                }

                            }

                            ?>

                        </tr>

                    <?php } ?>

                </tbody>

            </table>

            <?php  echo frontend_pagination_search($rowcountTotal,$pagination_url); ?>

        </div>

    </div>

     <?php

} else { ?>

    <div id="baby-name-results-container search-container" class="margin-top-30">

        <div class="margin-bottom-20">

            <div class="baby-name-tool-title">

                <h1 class="baby-name-tool-title">

                <?php echo "Nie znaleziono wyników dla ".$SearchString;?>

            </h1>

            </div>

        </div>

       <!-- <div class="margin-bottom-20">

                <ul class="nav nav-tabs hidden-print baby-names-tab">

                <li class="<?php if(($_GET['all'] == "all") || ((isset($_GET['genderVal'])) && ($_GET['genderVal'] ==''))) :echo 'active';endif;?>"><a href="<?php echo $all_url;?>">Toate</a></li>

            <li class="<?php if(($_GET['boy'] == "boy") || ($_GET['genderVal'] == "boy")) :echo 'active';endif;?>"><a href="<?php echo $boys_url;?>">Baieti</a></li>

            <li class="<?php if(($_GET['girl'] == "girl") || ($_GET['genderVal'] == "girl")) :echo 'active';endif;?>"><a href="<?php echo $girls_url;?>">Fete</a></li>

                </ul>

            </div> -->

    </div>

    <?php

}



}



/** End Results For form Search **/



?>







<div class="bg-white">

<h3>Szukaj według litery</h3>

<div class="baby-name-characters">

    <?php $alphabet_series = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'];

    for($i=0;$i<=count($alphabet_series);$i++) {

      echo "<a onclick=letterClick('$alphabet_series[$i]','$gender_att',1) href='javascript:void(0);' href='javascript:void(0);'>".$alphabet_series[$i]."</a>";

}   ?>

</div>



</div>







<div id="overlay" class="ajax-loader"><div><img src="<?php echo plugins_url() ?>/baby-name-generator/frontend/loading.gif" width="64px" height="64px"/></div></div>







<div class="margin-bottom-30 bg-white">

<h3> Szukaj według kategorii</h3>

<div class="category-table">

    <?php

   // $names = $wpdb->get_results("SELECT * FROM $baby_category_table ORDER BY `name` ASC");

    $names = $wpdb->get_results("SELECT DISTINCT $baby_category_table.id, $baby_category_table.name FROM $baby_category_table INNER JOIN $baby_names_table ON $baby_category_table.id = $baby_names_table.directory and $baby_names_table.gender = '$gender_att' ORDER BY $baby_category_table.name ASC");

    foreach($names as $name) {

        echo "<div class='categories margin-bottom-10'>

        <a onclick=catAjax($name->id,'$gender_att',1) href='javascript:void(0);'>".$name->name."</a>

        </div>";

    }

    ?>

</div>

<div id="baby-name-query-container">

    <div class="grey-background padding-15">

        <form id="searchInput" name="" method="GET" action="<?php echo get_permalink(); ?>">

            <div class="row query">

                <div class="col-sm-8">

                    <div class="form-group">

                        <label for="SearchTerm">Szukaj Nazwa</label>

                        <input class="form-control" id="searchTerm" name="searchTerm" placeholder="" type="text" value="<?php if($_GET['searchTerm']):echo $_GET['searchTerm'];endif;?>">

                    </div>

                </div>

            </div>

            <div class="row">

                <div class="col-sm-4">

                    <input type="submit" id="searhFormButton" name="custom_search" value="Szukaj" data-baby-name-search="" class="btn btn-lg btn-primary btn-block">

                </div>

            </div>

        </form>

    </div>

</div>



<!-- </div>  new div ending-->



<?php }







add_shortcode('generatorname', 'baby_names_generator');







add_action( 'wp_ajax_cat_ajax', 'cat_ajax' );



add_action('wp_ajax_nopriv_cat_ajax', 'cat_ajax');







function cat_ajax() {

global $wpdb;

global $baby_category_table;

global $baby_names_table;

$catResultHtml = "";

if (!empty($_POST)) {

    $category_id = $_POST['catID'];

    $gender_att = $_POST['gender_att'];

    $pages = $_POST['pages'];

    if($gender_att == 'boy') {

        $baby_names = get_cat_records1($category_id,$gender_att,$pages);

        $rowcountTotal = $wpdb->get_var("SELECT COUNT(*) FROM $baby_names_table WHERE `directory` = $category_id AND `gender` = '$gender_att' ORDER BY `name` ASC");

    } elseif($gender_att == 'girl') {

        $baby_names = get_cat_records1($category_id,$gender_att,$pages);

        $rowcountTotal = $wpdb->get_var("SELECT COUNT(*) FROM $baby_names_table WHERE `directory` = $category_id AND `gender` = '$gender_att' ORDER BY `name` ASC");

    }

}





$category_name = $wpdb->get_results("SELECT `name` FROM $baby_category_table WHERE `id` = $category_id");

if(count($baby_names) > 0) {

    $catResultHtml .= "<div id='baby-name-results-container' class='margin-top-30'>";

    $catResultHtml .="<div class='baby-name-tool-title'>";

    $catResultHtml .= "<h1 class='baby-name-tool-title'>";

    if(count($category_name) > 0):

        $catResultHtml .= "Wyszukiwania Z Kategoria - ".$category_name[0]->name;

        endif;

    $catResultHtml .= "</h1></div>";

    $catResultHtml .= "<div class='baby-name-list'>";

    $catResultHtml .= "<table class='table'>";

    $catResultHtml .= "<thead>";

    $catResultHtml .="<tr>";

    $catResultHtml .="<th>Nazwa</th>";

    $catResultHtml .="<th>Płeć</th></tr></thead>";

    $catResultHtml .="<tbody>";

    foreach($baby_names as $bnames) {

        $catResultHtml .="<tr>";

        $catResultHtml .= "<td>";

        $catResultHtml .= $bnames->name;

        $catResultHtml .= "</td>";

        if($_GET['boy'] == 'boy') {

            $catResultHtml .="<td>";

            $catResultHtml .= "<i class='fa fa-mars fa-2x' aria-hidden='true'></i></td>";

        } elseif($_GET['girl'] == 'girl') {

            $catResultHtml .= "<td><i class='fa fa-venus fa-2x' aria-hidden='true'></i></td>";

        } else {

            if($bnames->gender == 'boy') {

                $catResultHtml .="<td><i class='fa fa-mars fa-2x' aria-hidden='true'></i></td>";

            } elseif($bnames->gender == 'girl') {

                $catResultHtml .="<td><i class='fa fa-venus fa-2x' aria-hidden='true'></i></td>";

            }

        }

        $catResultHtml .="</tr>";

    }

    $catResultHtml .="</tbody></table></div></div>";

    $catResultHtml .= "<div id='pagi_data'>";

    $catResultHtml .= frontend_pagination($rowcountTotal,$pages,$category_id,$gender_att);

    $catResultHtml .= "</div>";

    } else {

        $catResultHtml .= "<div id='baby-name-results-container' class='margin-top-30'>";

        $catResultHtml .= "<div class='margin-bottom-20'>";

        $catResultHtml .= "<div class='baby-name-tool-title'>";

        $catResultHtml .= "<h1 class='baby-name-tool-title'>";

        if(count($category_name) > 0):

            $catResultHtml .="Nie znaleziono wyników dla ".$category_name[0]->name.' Category';

        endif;





        $catResultHtml .="</h1>";

        $catResultHtml .="</div>";

        $catResultHtml .="</div>";

        $catResultHtml .="</div>";

    }



   echo  $catResultHtml;



   exit();



}











add_action( 'wp_ajax_letter_ajax', 'letter_ajax' );



add_action('wp_ajax_nopriv_letter_ajax', 'letter_ajax');







function letter_ajax() {

global $wpdb;

global $baby_category_table;

global $baby_names_table;

$ResultHtml = "";

if (!empty($_POST)) {

    $LetterStartsWith = $_POST['letter'];

    $gender_att = $_POST['gender_att'];

    $pages = $_POST['pages'];

    if($gender_att == 'boy') {

        $letter_search_names = get_letter_records($LetterStartsWith,$gender_att);

        $resultSet = $wpdb->get_results("SELECT DISTINCT `name`,`gender` FROM $baby_names_table WHERE `letter` = '$LetterStartsWith' AND `gender` = '$gender_att' ORDER BY `name` ASC");

        $rowcountTotal = $wpdb->num_rows;

    } elseif($gender_att == 'girl') {

        $letter_search_names = get_letter_records($LetterStartsWith,$gender_att);

        $resultSet = $wpdb->get_results("SELECT DISTINCT `name`,`gender` FROM $baby_names_table WHERE `letter` = '$LetterStartsWith' AND `gender` = '$gender_att' ORDER BY `name` ASC");

        $rowcountTotal = $wpdb->num_rows;

    }





    if(count($letter_search_names) > 0) {

        $ResultHtml .="<div id='baby-name-results-container' class='margin-top-30'>";

        $ResultHtml .= "<div class='baby-name-tool-title'>";

        $ResultHtml .= "<h1 class='baby-name-tool-title'>";

        $ResultHtml .= "Nume de copii care incep cu - ".$LetterStartsWith;

        $ResultHtml .= "</h1>";

        $ResultHtml .=  "</div>";

        $ResultHtml .= "<div class='baby-name-list'>";

        $ResultHtml .=  "<table class='table'>";

        $ResultHtml .= "<thead><tr><th>Nazwa</th><th>Płeć</th></tr></thead><tbody>";

        foreach($letter_search_names as $bnames) {

            $ResultHtml .="<tr>";

            $ResultHtml .=  "<td>";

            $ResultHtml .= $bnames->name;

            $ResultHtml .= "</td>";

            if($_GET['boy'] == 'boy') {

                $ResultHtml .=  "<td><i class='fa fa-mars fa-2x' aria-hidden='true'></i></td>";

                } elseif($_GET['girl'] == 'girl') {

                    $ResultHtml .= "<td><i class='fa fa-venus fa-2x' aria-hidden='true'></i></td>";

                } else {

                    if($bnames->gender == 'boy') {

                        $ResultHtml .= "<td><i class='fa fa-mars fa-2x' aria-hidden='true'></i></td>";

                    } elseif($bnames->gender == 'girl') {

                        $ResultHtml .=  "<td><i class='fa fa-venus fa-2x' aria-hidden='true'></i></td>";

                    }

                }

                $ResultHtml .= "</tr>";

        }

        $ResultHtml .= "</tbody>";

        $ResultHtml .= "</table>";

        $ResultHtml .= frontend_pagination_letter($rowcountTotal,$pages,$LetterStartsWith,$gender_att);

        $ResultHtml .= "</div>";

        $ResultHtml .= "</div>";

    } else {

        $ResultHtml .= "<div id='baby-name-results-container' class='margin-top-30'>";

        $ResultHtml .= "<div class='margin-bottom-20'>";

        $ResultHtml .= "<div class='baby-name-tool-title'>";

        $ResultHtml .= "<h1 class='baby-name-tool-title'>";

        $ResultHtml .= "Nie znaleziono wyników dla ".$LetterStartsWith;

        $ResultHtml .= "</h1></div></div></div>";

   }

}

echo  $ResultHtml;

exit();



}







function dog_names_generator() {

global $wpdb;

global $dog_category_table;

global $dog_names_table;



   /* if(!empty($atts)) {

      $gender_att = $atts['gen'];

} */



?>



<link type="text/css" rel="stylesheet" href="<?php echo plugins_url(); ?>/baby-name-generator/frontend/name-generator.css?v=<?php echo mt_rand();?>">



<script src="<?php echo plugins_url() ?>/baby-name-generator/frontend/shortcode.js?v=<?php echo mt_rand();?>"></script>



<script>var admin_ajx_url = "<?php echo admin_url('admin-ajax.php'); ?>";</script>



<div class="SectionsContainer">



<div id='categoryContainer'></div>



<?php



/** Results For Search Form **/



if($_GET['custom_search'] && $_GET['custom_search'] == 'Szukaj' ) {

$SearchString = filter_var($_GET['searchTerm'],FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);

$custom_search = filter_var($_GET['custom_search'],FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);

$gender_search = filter_var($_GET['genderVal'],FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);

if(isset($gender_search) && ($gender_search!='')) {

    $new_search_url = get_permalink().'?searchTerm='.$SearchString.'&genderVal='.$gender_search.'&custom_search='.$custom_search;

    $new_search_url_rm_search = get_permalink().'?searchTerm='.$SearchString.'&custom_search='.$custom_search;

    $all_url = $new_search_url_rm_search.'&all=all';

    $boys_url  = $new_search_url_rm_search.'&boy=boy';

    $girls_url = $new_search_url_rm_search.'&girl=girl';

} else {

    $new_search_url = get_permalink().'?searchTerm='.$SearchString.'&custom_search='.$custom_search;

    $all_url = $new_search_url.'&all=all';

}







  //   if($gender_att == 'boy') {

      $search_records = get_dogs_search_records($SearchString,$gender_att);

    if(strlen($SearchString) == '1') {

        $resultSet = $wpdb->get_results("SELECT DISTINCT `name`,`gender` FROM $dog_names_table WHERE `name` LIKE '".$SearchString."%' AND `gender` = '$gender_att' ORDER BY `name` ASC");

        $rowcountTotal = $wpdb->num_rows;

       // $rowcountTotal = $wpdb->get_var("SELECT COUNT(*) FROM $baby_names_table WHERE `name` LIKE '".$SearchString."%' AND `gender` = '$gender_att' ORDER BY `name` ASC");

    } else {

        $resultSet = $wpdb->get_results("SELECT DISTINCT `name`,`gender` FROM $dog_names_table WHERE `name` LIKE '%".$SearchString."%' AND `gender` = '$gender_att' ORDER BY `name` ASC");

        $rowcountTotal = $wpdb->num_rows;

      //  $rowcountTotal = $wpdb->get_var("SELECT COUNT(*) FROM $baby_names_table WHERE `name` LIKE '%".$SearchString."%' AND `gender` = '$gender_att' ORDER BY `name` ASC");

    }

      $pagination_url = $all_url;

      $gender_hidden_val = $gender_att;



   //   }





if(count($search_records) > 0) { ?>

    <div id="baby-name-results-container" class="margin-top-30 search-container">

        <div class="baby-name-tool-title">

            <h1 class="baby-name-tool-title">

            <?php echo "Wyniki wyszukiwania dla - ".$SearchString;?>

            </h1>

        </div>

        <div class="baby-name-list">

            <table class="table">

                <thead>

                    <tr>

                        <th>

                        Nazwa

                        </th>

                    </tr>

                </thead>

                <tbody>

                    <?php foreach($search_records as $bnames) {  ?>

                        <tr>

                            <td><?php echo $bnames->name; ?></td>

                            <?php if($_GET['boy'] == 'boy') {

                                echo '<td><i class="fa fa-mars fa-2x" aria-hidden="true"></i></td>';

                            } elseif($_GET['girl'] == 'girl') {

                                echo '<td><i class="fa fa-venus fa-2x" aria-hidden="true"></i></td>';

                            } else {

                                if($bnames->gender == 'boy') {

                                    echo '<td><i class="fa fa-mars fa-2x" aria-hidden="true"></i></td>';

                                } elseif($bnames->gender == 'girl') {

                                    echo '<td><i class="fa fa-venus fa-2x" aria-hidden="true"></i></td>';

                                }

                            }

                            ?>

                        </tr>

                    <?php } ?>

                </tbody>

            </table>

            <?php  echo frontend_pagination_dog_search($rowcountTotal,$pagination_url); ?>

        </div>

    </div>

     <?php

} else { ?>

    <div id="baby-name-results-container search-container" class="margin-top-30">

        <div class="margin-bottom-20">

            <div class="baby-name-tool-title">

                <h1 class="baby-name-tool-title">

                <?php echo "Nie znaleziono wyników dla ".$SearchString;?>

            </h1>

            </div>

        </div>

       <!-- <div class="margin-bottom-20">

                <ul class="nav nav-tabs hidden-print baby-names-tab">

                <li class="<?php if(($_GET['all'] == "all") || ((isset($_GET['genderVal'])) && ($_GET['genderVal'] ==''))) :echo 'active';endif;?>"><a href="<?php echo $all_url;?>">Wszyscy</a></li>

            <li class="<?php if(($_GET['boy'] == "boy") || ($_GET['genderVal'] == "boy")) :echo 'active';endif;?>"><a href="<?php echo $boys_url;?>">Baieti</a></li>

            <li class="<?php if(($_GET['girl'] == "girl") || ($_GET['genderVal'] == "girl")) :echo 'active';endif;?>"><a href="<?php echo $girls_url;?>">Fete</a></li>

                </ul>

            </div> -->

    </div>

    <?php

}



}



/** End Results For form Search **/



?>







<div class="bg-white">

<h3>Szukaj według litery</h3>

<div class="baby-name-characters">

    <?php $alphabet_series = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'];

    for($i=0;$i<=count($alphabet_series);$i++) {

      echo "<a onclick=letterClickDogs('$alphabet_series[$i]',1) href='javascript:void(0);' href='javascript:void(0);'>".$alphabet_series[$i]."</a>";

}   ?>

</div>



</div>







<div id="overlay" class="ajax-loader"><div><img src="<?php echo plugins_url() ?>/baby-name-generator/frontend/loading.gif" width="64px" height="64px"/></div></div>







<div class="margin-bottom-30 bg-white">

<h3> Szukaj według kategorii</h3>

<div class="category-table">

    <?php

   // $names = $wpdb->get_results("SELECT * FROM $baby_category_table ORDER BY `name` ASC");

    $names = $wpdb->get_results("SELECT * FROM $dog_category_table ORDER BY `name` ASC");

    //$names = $wpdb->get_results("SELECT DISTINCT $dog_category_table.id, $dog_category_table.name FROM $dog_category_table INNER JOIN $dog_names_table ON $dog_category_table.id = $dog_names_table.directory and $dog_names_table.gender = '$gender_att' ORDER BY $dog_category_table.name ASC");

    foreach($names as $name) {

        echo "<div class='categories margin-bottom-10'>

        <a onclick=dogCatAjax($name->id,1) href='javascript:void(0);'>".$name->name."</a>

        </div>";

    }

    ?>

</div>

<div id="baby-name-query-container">

    <div class="grey-background padding-15">

        <form id="searchInput" name="" method="GET" action="<?php echo get_permalink(); ?>">

            <div class="query">

                <div class="col-sm-8">

                    <div class="form-group">

                        <label for="SearchTerm">Szukaj Nazwa</label>

                        <input class="form-control" id="searchTerm" name="searchTerm" placeholder="" type="text" value="<?php if($_GET['searchTerm']):echo $_GET['searchTerm'];endif;?>">

                    </div>

                </div>

            </div>

            <div>

                <div class="col-sm-4">

                    <input type="submit" id="searhFormButton" name="custom_search" value="Szukaj" data-baby-name-search="" class="btn btn-lg btn-primary btn-block">

                </div>

            </div>

        </form>

    </div>

</div>



</div>



<?php



}



add_shortcode('generator_dog_name', 'dog_names_generator');







add_action( 'wp_ajax_dogCat_ajax', 'dogCat_ajax' );



add_action('wp_ajax_nopriv_dogCat_ajax', 'dogCat_ajax');



function dogCat_ajax() {

global $wpdb;

global $dog_category_table;

global $dog_names_table;

$catResultHtml = "";

if (!empty($_POST)) {

    $category_id = $_POST['catID'];

    $gender_att = $_POST['gender_att'];

    $pages = $_POST['pages'];

    $baby_names = get_cat_records1_dogs($category_id,$gender_att,$pages);

    $rowcountTotal = $wpdb->get_var("SELECT COUNT(*) FROM $dog_names_table WHERE `directory` = $category_id ORDER BY `name` ASC");

  /*  if($gender_att == 'boy') {

        $baby_names = get_cat_records1($category_id,$gender_att,$pages);

        $rowcountTotal = $wpdb->get_var("SELECT COUNT(*) FROM $dog_names_table WHERE `directory` = $category_id AND `gender` = '$gender_att' ORDER BY `name` ASC");

    } elseif($gender_att == 'girl') {

        $baby_names = get_cat_records1($category_id,$gender_att,$pages);

        $rowcountTotal = $wpdb->get_var("SELECT COUNT(*) FROM $dog_names_table WHERE `directory` = $category_id AND `gender` = '$gender_att' ORDER BY `name` ASC");

    } */

}





$category_name = $wpdb->get_results("SELECT `name` FROM $dog_category_table WHERE `id` = $category_id");

if(count($baby_names) > 0) {

    $catResultHtml .= "<div id='baby-name-results-container' class='margin-top-30'>";

    $catResultHtml .="<div class='baby-name-tool-title'>";

    $catResultHtml .= "<h1 class='baby-name-tool-title'>";

    if(count($category_name) > 0):

        $catResultHtml .= "Wyszukiwania Dla Kategoria - ".$category_name[0]->name;

        endif;

    $catResultHtml .= "</h1></div>";

    $catResultHtml .= "<div class='baby-name-list'>";

    $catResultHtml .= "<table class='table'>";

    $catResultHtml .= "<thead>";

    $catResultHtml .="<tr>";

    $catResultHtml .="<th>Nazwa</th>";

 //   $catResultHtml .="<th>Gen</th></tr></thead>";

    $catResultHtml .="<tbody>";

    foreach($baby_names as $bnames) {

        $catResultHtml .="<tr>";

        $catResultHtml .= "<td>";

        $catResultHtml .= $bnames->name;

        $catResultHtml .= "</td>";

       /* if($_GET['boy'] == 'boy') {

            $catResultHtml .="<td>";

            $catResultHtml .= "<i class='fa fa-mars fa-2x' aria-hidden='true'></i></td>";

        } elseif($_GET['girl'] == 'girl') {

            $catResultHtml .= "<td><i class='fa fa-venus fa-2x' aria-hidden='true'></i></td>";

        } else {

            if($bnames->gender == 'boy') {

                $catResultHtml .="<td><i class='fa fa-mars fa-2x' aria-hidden='true'></i></td>";

            } elseif($bnames->gender == 'girl') {

                $catResultHtml .="<td><i class='fa fa-venus fa-2x' aria-hidden='true'></i></td>";

            }

        } */

        $catResultHtml .="</tr>";

    }

    $catResultHtml .="</tbody></table></div></div>";

    $catResultHtml .= "<div id='pagi_data'>";

    $catResultHtml .= frontend_dog_pagination($rowcountTotal,$pages,$category_id);

    $catResultHtml .= "</div>";

    } else {

        $catResultHtml .= "<div id='baby-name-results-container' class='margin-top-30'>";

        $catResultHtml .= "<div class='margin-bottom-20'>";

        $catResultHtml .= "<div class='baby-name-tool-title'>";

        $catResultHtml .= "<h1 class='baby-name-tool-title'>";

        if(count($category_name) > 0):

            $catResultHtml .="Nie znaleziono wyników dla ".$category_name[0]->name.' Category';

        endif;





        $catResultHtml .="</h1>";

        $catResultHtml .="</div>";

        $catResultHtml .="</div>";

        $catResultHtml .="</div>";

    }



   echo  $catResultHtml;



   exit();



}







add_action( 'wp_ajax_letter_ajax_dogs', 'letter_ajax_dogs' );



add_action('wp_ajax_nopriv_letter_ajax_dogs', 'letter_ajax_dogs');







function letter_ajax_dogs() {

global $wpdb;

global $dog_category_table;

global $dog_names_table;

$ResultHtml = "";

if (!empty($_POST)) {

    $LetterStartsWith = $_POST['letter'];

    $gender_att = $_POST['gender_att'];

    $pages = $_POST['pages'];

 /*   if($gender_att == 'boy') {

        $letter_search_names = get_letter_records($LetterStartsWith,$gender_att);

        $resultSet = $wpdb->get_results("SELECT DISTINCT `name`,`gender` FROM $baby_names_table WHERE `letter` = '$LetterStartsWith' AND `gender` = '$gender_att' ORDER BY `name` ASC");

        $rowcountTotal = $wpdb->num_rows;

    } elseif($gender_att == 'girl') {

        $letter_search_names = get_letter_records($LetterStartsWith,$gender_att);

        $resultSet = $wpdb->get_results("SELECT DISTINCT `name`,`gender` FROM $baby_names_table WHERE `letter` = '$LetterStartsWith' AND `gender` = '$gender_att' ORDER BY `name` ASC");

        $rowcountTotal = $wpdb->num_rows;

    } */





    $letter_search_names = get_letter_records_dogs($LetterStartsWith,$gender_att);

    $resultSet = $wpdb->get_results("SELECT DISTINCT `name` FROM $dog_names_table WHERE `letter` = '$LetterStartsWith' ORDER BY `name` ASC");

    $rowcountTotal = $wpdb->num_rows;





    if(count($letter_search_names) > 0) {

        $ResultHtml .="<div id='baby-name-results-container' class='margin-top-30'>";

        $ResultHtml .= "<div class='baby-name-tool-title'>";

        $ResultHtml .= "<h1 class='baby-name-tool-title'>";

        $ResultHtml .= "Imiona dla dzieci zaczynające się od - ".$LetterStartsWith;

        $ResultHtml .= "</h1>";

        $ResultHtml .=  "</div>";

        $ResultHtml .= "<div class='baby-name-list'>";

        $ResultHtml .=  "<table class='table'>";

        $ResultHtml .= "<thead><tr><th>Nazwa</th></tr></thead><tbody>";

        foreach($letter_search_names as $bnames) {

            $ResultHtml .="<tr>";

            $ResultHtml .=  "<td>";

            $ResultHtml .= $bnames->name;

            $ResultHtml .= "</td>";

            /* if($_GET['boy'] == 'boy') {

                $ResultHtml .=  "<td><i class='fa fa-mars fa-2x' aria-hidden='true'></i></td>";

                } elseif($_GET['girl'] == 'girl') {

                    $ResultHtml .= "<td><i class='fa fa-venus fa-2x' aria-hidden='true'></i></td>";

                } else {

                    if($bnames->gender == 'boy') {

                        $ResultHtml .= "<td><i class='fa fa-mars fa-2x' aria-hidden='true'></i></td>";

                    } elseif($bnames->gender == 'girl') {

                        $ResultHtml .=  "<td><i class='fa fa-venus fa-2x' aria-hidden='true'></i></td>";

                    }

                } */

                $ResultHtml .= "</tr>";

        }

        $ResultHtml .= "</tbody>";

        $ResultHtml .= "</table>";

        $ResultHtml .= frontend_pagination_letter_dogs($rowcountTotal,$pages,$LetterStartsWith);

        $ResultHtml .= "</div>";

        $ResultHtml .= "</div>";

    } else {

        $ResultHtml .= "<div id='baby-name-results-container' class='margin-top-30'>";

        $ResultHtml .= "<div class='margin-bottom-20'>";

        $ResultHtml .= "<div class='baby-name-tool-title'>";

        $ResultHtml .= "<h1 class='baby-name-tool-title'>";

        $ResultHtml .= "Nie znaleziono wyników dla ".$LetterStartsWith;

        $ResultHtml .= "</h1></div></div></div>";

   }

}

echo  $ResultHtml;

exit();



}