<?php

/**



 * Plugin Name: Baby Name Generator



 * Plugin URI: https://Baby-Name-Generator



 * Description: Add categories and baby names to them, Can browse names on the frontend using filter.



 * Version: 1.1



 * Author: Trigma



 */







global $wpdb;



global $baby_category_table;



$baby_category_table = $wpdb->prefix . "baby_category";







global $dog_category_table;



$dog_category_table = $wpdb->prefix . "dog_category";







global $baby_names_table;



$baby_names_table = $wpdb->prefix . "baby_names";







global $dog_names_table;



$dog_names_table = $wpdb->prefix . "dog_names";







/* The helpers and the shortcode are responsible for everything that happens on the frontend */



require_once dirname( __FILE__ ) . '/helpers.php';



//require_once dirname( __FILE__ ) . '/shortcode.php';



require_once dirname( __FILE__ ) . '/shortcodes.php';



/**



 * We only need admin functionality and database setup as admins



 */



if (is_admin())



{



    require_once dirname( __FILE__ ) . '/admin.php';



  //  require_once dirname( __FILE__ ) . '/admin_general_settings.php';



  //  require_once dirname( __FILE__ ) . '/database.php';







    /* These register_activation_hooks run after install */



    register_activation_hook( __FILE__, 'baby_names_db_tables' );







    function baby_names_db_tables() {



    global $name_directory_db_version;



    global $baby_category_table;



    global $baby_names_table;



    global $dog_category_table;



    global $dog_names_table;







    $name_directory_table_queries = array("



        CREATE TABLE $baby_category_table (



            id INT( 11 ) NOT NULL AUTO_INCREMENT,



            name VARCHAR( 255 ) NOT NULL,



            created_at DATETIME,



            UNIQUE KEY id (id),



            PRIMARY KEY (id));",



            "



        CREATE TABLE $dog_category_table (



            id INT( 11 ) NOT NULL AUTO_INCREMENT,



            name VARCHAR( 255 ) NOT NULL,



            created_at DATETIME,



            UNIQUE KEY id (id),



            PRIMARY KEY (id));",







        "CREATE TABLE $baby_names_table (



            id INT( 11 ) NOT NULL AUTO_INCREMENT,



            directory INT( 11 ) NOT NULL ,



            name VARCHAR( 255 ) NOT NULL ,



            letter VARCHAR( 1 ) NOT NULL ,



            gender VARCHAR( 255 ) NOT NULL ,



            UNIQUE KEY id (id),



            PRIMARY KEY (id));",







            "CREATE TABLE $dog_names_table (



                id INT( 11 ) NOT NULL AUTO_INCREMENT,



                directory INT( 11 ) NOT NULL ,



                name VARCHAR( 255 ) NOT NULL ,



                letter VARCHAR( 1 ) NOT NULL ,



                UNIQUE KEY id (id),



                PRIMARY KEY (id));"







    );







    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );







    dbDelta( $name_directory_table_queries );







    update_option("name_directory_db_version", $name_directory_db_version);



}







    /* This hook is for updates */



   // add_action( 'plugins_loaded', 'name_directory_post_update' );



}