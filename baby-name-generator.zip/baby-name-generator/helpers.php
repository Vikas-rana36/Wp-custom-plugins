<?php



/**



 * This file is part of the NameDirectory plugin for WordPress



 */











/**



 * Check whether the mb_string extension is supported on this installation



 * @return bool



 */



function name_directory_is_multibyte_supported1()



{



    if(function_exists('mb_strtoupper'))



    {



        return true;



    }







    return false;



}







function name_directory_get_first_char1($name)



{



    if(name_directory_is_multibyte_supported1())



    {



        $first_char = mb_strtoupper(mb_substr($name, 0, 1));



    }



    else



    {



        $first_char = strtoupper(substr($name, 0, 1));



    }







    if(is_numeric($first_char))



    {



        $first_char = '#';



    }







    return $first_char;



}











function name_directory_name_exists_in_directory1($name, $directory,$gender)



{



    global $wpdb;



    global $baby_names_table;



    $name_directory_settings = get_option('name_directory_general_option');







    if ( ! empty($name_directory_settings['disable_duplicate_protection']) ) {



        return false;



    }







    $wpdb->get_results(sprintf("SELECT 1 FROM `%s` WHERE `name` = '%s' AND `gender` = '%s' AND `directory` = %d",



    $baby_names_table, esc_sql($name), esc_sql($gender),intval($directory)));







    return (bool)$wpdb->num_rows;



}







function name_directory_name_exists_in_directory_dog($name, $directory)



{



    global $wpdb;



    global $dog_names_table;



    $name_directory_settings = get_option('name_directory_general_option');







    if ( ! empty($name_directory_settings['disable_duplicate_protection']) ) {



        return false;



    }







    $wpdb->get_results(sprintf("SELECT 1 FROM `%s` WHERE `name` = '%s' AND `directory` = %d",



    $dog_names_table, esc_sql($name), intval($directory)));







    return (bool)$wpdb->num_rows;



}







/**



 * Render header and footer of the overview-table



 */



function name_directory_render_admin_overview_table_headerfooter1()



{



    echo '<tr>

<th width="1%" scope="col" class="manage-column column-cb check-column">&nbsp;</th>

<th width="52%" scope="col" id="title" class="manage-column column-title sortable desc">

    <span>' . __('Title', 'name-directory') . '</span>

</th>

<th width="13%" scope="col">' . __('Entries', 'name-directory') . '</th>



        </tr>';



}







function get_cat_records($category_id,$gender = false) {



    global $wpdb;



    global $baby_names_table;



    if(!empty($_GET['pages'])){



        if (isset($_GET['record'])) {

$record = $_GET['record'];



        }else{

$record = 20;



        }



        $rowcount = $wpdb->get_var("SELECT COUNT(*) FROM $baby_names_table WHERE `directory` = $category_id ORDER BY `name` ASC");



        $results_per_page = $record;







        $start_from = ($_GET['pages']-1) * $results_per_page;







        if (isset($_GET['orderBy'])) {

$orderstatus = $_GET['orderBy'];



        }else{

$orderstatus = 'DESC';



        }



        if(!empty($gender)) {

$baby_names = $wpdb->get_results("SELECT * FROM $baby_names_table WHERE `directory` = $category_id AND `gender` = '$gender' ORDER BY `name` $orderstatus LIMIT $start_from,$results_per_page");



        } else {

$baby_names = $wpdb->get_results("SELECT * FROM $baby_names_table WHERE `directory` = $category_id ORDER BY `name` $orderstatus LIMIT $start_from,$results_per_page");



        }











    }else{



        $pages = '1';



        if (isset($_GET['record'])) {

$limited = $_GET['record'];



        }else{

$limited = 20;



        }







        if (isset($_GET['orderBy'])) {

$orderstatus = $_GET['orderBy'];



        }else{

$orderstatus = 'ASC';



        }



        if(!empty($gender)) {

$baby_names = $wpdb->get_results("SELECT * FROM $baby_names_table WHERE `directory` = $category_id AND `gender` = '$gender' ORDER BY `name` $orderstatus LIMIT ".$limited."");



        } else {

$baby_names = $wpdb->get_results("SELECT * FROM $baby_names_table WHERE `directory` = $category_id ORDER BY `name` $orderstatus LIMIT ".$limited."");



        }



       // echo $wpdb->last_query;



       // echo $wpdb->last_query;



    }



   // echo $wpdb->last_query;



    return $baby_names;







}







function get_cat_records1($category_id,$gender = false,$pages) {



    global $wpdb;



    global $baby_names_table;



    if($pages > 1){



      /*  if (isset($_GET['record'])) {

$record = $_GET['record'];



        }else{

$record = 20;



        } */



        $record = 20;



        $rowcount = $wpdb->get_var("SELECT COUNT(*) FROM $baby_names_table WHERE `directory` = $category_id ORDER BY `name` ASC");



        $results_per_page = $record;







      //  $start_from = ($_GET['pages']-1) * $results_per_page;



        $start_from = ($pages-1) * $results_per_page;



        $orderstatus = 'DESC';



        if(!empty($gender)) {

$baby_names = $wpdb->get_results("SELECT * FROM $baby_names_table WHERE `directory` = $category_id AND `gender` = '$gender' ORDER BY `name` $orderstatus LIMIT $start_from,$results_per_page");



        } else {

$baby_names = $wpdb->get_results("SELECT * FROM $baby_names_table WHERE `directory` = $category_id ORDER BY `name` $orderstatus LIMIT $start_from,$results_per_page");



        }











    }else{



        $pages = '1';



        $limited = 20;



        $orderstatus = 'ASC';



        if(!empty($gender)) {

$baby_names = $wpdb->get_results("SELECT * FROM $baby_names_table WHERE `directory` = $category_id AND `gender` = '$gender' ORDER BY `name` $orderstatus LIMIT ".$limited."");



        } else {

$baby_names = $wpdb->get_results("SELECT * FROM $baby_names_table WHERE `directory` = $category_id ORDER BY `name` $orderstatus LIMIT ".$limited."");



        }



       // echo $wpdb->last_query;



       // echo $wpdb->last_query;



    }



   // echo $wpdb->last_query;



    return $baby_names;







}







function get_cat_records1_dogs($category_id,$gender = false,$pages) {



    global $wpdb;



    global $dog_names_table;



    if($pages > 1){



      /*  if (isset($_GET['record'])) {

$record = $_GET['record'];



        }else{

$record = 20;



        } */



        $record = 20;



        $rowcount = $wpdb->get_var("SELECT COUNT(*) FROM $baby_names_table WHERE `directory` = $category_id ORDER BY `name` ASC");



        $results_per_page = $record;







      //  $start_from = ($_GET['pages']-1) * $results_per_page;



        $start_from = ($pages-1) * $results_per_page;



        $orderstatus = 'DESC';



        if(!empty($gender)) {

$baby_names = $wpdb->get_results("SELECT * FROM $dog_names_table WHERE `directory` = $category_id AND `gender` = '$gender' ORDER BY `name` $orderstatus LIMIT $start_from,$results_per_page");



        } else {

$baby_names = $wpdb->get_results("SELECT * FROM $dog_names_table WHERE `directory` = $category_id ORDER BY `name` $orderstatus LIMIT $start_from,$results_per_page");



        }











    }else{



        $pages = '1';



        $limited = 20;



        $orderstatus = 'ASC';



        if(!empty($gender)) {

$baby_names = $wpdb->get_results("SELECT * FROM $dog_names_table WHERE `directory` = $category_id AND `gender` = '$gender' ORDER BY `name` $orderstatus LIMIT ".$limited."");



        } else {

$baby_names = $wpdb->get_results("SELECT * FROM $dog_names_table WHERE `directory` = $category_id ORDER BY `name` $orderstatus LIMIT ".$limited."");



        }



       // echo $wpdb->last_query;



       // echo $wpdb->last_query;



    }



   // echo $wpdb->last_query;



    return $baby_names;







}



///////////



function get_letter_records($LetterStartsWith,$gender = false) {



    global $wpdb;



    global $baby_names_table;



    if(!empty($_GET['pages'])){



        if (isset($_GET['record'])) {

$record = $_GET['record'];



        }else{

$record = 20;



        }



        $rowcount = $wpdb->get_var("SELECT COUNT(*) FROM $baby_names_table WHERE `letter` = '$LetterStartsWith' ORDER BY `name` ASC");



        $results_per_page = $record;







        $start_from = ($_GET['pages']-1) * $results_per_page;







        if (isset($_GET['orderBy'])) {

$orderstatus = $_GET['orderBy'];



        }else{

$orderstatus = 'DESC';



        }



        if(!empty($gender)) {

$baby_names = $wpdb->get_results("SELECT DISTINCT `name`,`gender` FROM $baby_names_table WHERE `letter` = '$LetterStartsWith' AND `gender` = '$gender' ORDER BY `name` $orderstatus LIMIT $start_from,$results_per_page");



        } else {

$baby_names = $wpdb->get_results("SELECT DISTINCT `name`,`gender` FROM $baby_names_table WHERE `letter` = '$LetterStartsWith' ORDER BY `name` $orderstatus LIMIT $start_from,$results_per_page");



        }











    }else {



        $pages = '1';



        if (isset($_GET['record'])) {

$limited = $_GET['record'];



        }else{

$limited = 20;



        }







        if (isset($_GET['orderBy'])) {

$orderstatus = $_GET['orderBy'];



        }else{

$orderstatus = 'ASC';



        }



        if(!empty($gender)) {

$baby_names = $wpdb->get_results("SELECT DISTINCT `name`,`gender` FROM $baby_names_table WHERE `letter` = '$LetterStartsWith' AND `gender` = '$gender' ORDER BY `name` $orderstatus LIMIT ".$limited."");



        } else {

$baby_names = $wpdb->get_results("SELECT DISTINCT `name`,`gender` FROM $baby_names_table WHERE `letter` = '$LetterStartsWith' ORDER BY `name` $orderstatus LIMIT ".$limited."");



        }



       // echo $wpdb->last_query;



      //  echo "<pre>";



       // print_r($baby_names);



    }



    return $baby_names;







}







function get_letter_records_dogs($LetterStartsWith,$gender = false) {



    global $wpdb;



    global $dog_names_table;



    if(!empty($_GET['pages'])){



        if (isset($_GET['record'])) {

$record = $_GET['record'];



        }else{

$record = 20;



        }



        $rowcount = $wpdb->get_var("SELECT COUNT(*) FROM $dog_names_table WHERE `letter` = '$LetterStartsWith' ORDER BY `name` ASC");



        $results_per_page = $record;







        $start_from = ($_GET['pages']-1) * $results_per_page;







        if (isset($_GET['orderBy'])) {

$orderstatus = $_GET['orderBy'];



        }else{

//$orderstatus = 'DESC';

$orderstatus = 'ASC';



        }



        if(!empty($gender)) {

$baby_names = $wpdb->get_results("SELECT DISTINCT `name`,`gender` FROM $dog_names_table WHERE `letter` = '$LetterStartsWith' AND `gender` = '$gender' ORDER BY `name` $orderstatus LIMIT $start_from,$results_per_page");



        } else {

$baby_names = $wpdb->get_results("SELECT DISTINCT `name` FROM $dog_names_table WHERE `letter` = '$LetterStartsWith' ORDER BY `name` $orderstatus LIMIT $start_from,$results_per_page");



        }











    }else {



        $pages = '1';



        if (isset($_GET['record'])) {

$limited = $_GET['record'];



        }else{

$limited = 20;



        }







        if (isset($_GET['orderBy'])) {

$orderstatus = $_GET['orderBy'];



        }else{

$orderstatus = 'ASC';



        }



        if(!empty($gender)) {

$baby_names = $wpdb->get_results("SELECT DISTINCT `name`,`gender` FROM $dog_names_table WHERE `letter` = '$LetterStartsWith' AND `gender` = '$gender' ORDER BY `name` $orderstatus LIMIT ".$limited."");



        } else {

$baby_names = $wpdb->get_results("SELECT DISTINCT `name` FROM $dog_names_table WHERE `letter` = '$LetterStartsWith' ORDER BY `name` $orderstatus LIMIT ".$limited."");



        }



       // echo $wpdb->last_query;



      //  echo "<pre>";



       // print_r($baby_names);



    }



    return $baby_names;







}







function get_search_records($search_param,$gender = false) {



    global $wpdb;



    global $baby_names_table;







    if(!empty($_GET['pages'])){



        if (isset($_GET['record'])) {

$record = $_GET['record'];



        }else{

$record = 20;



        }



 //       $rowcount = $wpdb->get_var("SELECT COUNT(*) FROM $baby_names_table WHERE `letter` = '$LetterStartsWith' ORDER BY `name` ASC");



        if(strlen($search_param) == '1') {

$rowcount = $wpdb->get_results("SELECT DISTINCT `name`,`gender` FROM $baby_names_table WHERE `name` LIKE '".$search_param."%' ORDER BY `name` ASC");



        } else {

$rowcount = $wpdb->get_results("SELECT DISTINCT `name`,`gender` FROM $baby_names_table WHERE `name` LIKE '%".$search_param."%' ORDER BY `name` ASC");



        }



        $results_per_page = $record;







        $start_from = ($_GET['pages']-1) * $results_per_page;







        if (isset($_GET['orderBy'])) {

$orderstatus = $_GET['orderBy'];



        }else{

$orderstatus = 'DESC';



        }



        if(!empty($gender)) {

if(strlen($search_param) == '1') {

    $baby_names = $wpdb->get_results("SELECT DISTINCT `name`,`gender` FROM $baby_names_table WHERE `name` LIKE '".$search_param."%' AND `gender` = '$gender' ORDER BY `name` $orderstatus LIMIT $start_from,$results_per_page");

} else {

    $baby_names = $wpdb->get_results("SELECT DISTINCT `name`,`gender` FROM $baby_names_table WHERE `name` LIKE '%".$search_param."%' AND `gender` = '$gender' ORDER BY `name` $orderstatus LIMIT $start_from,$results_per_page");

}



        } else {

if(strlen($search_param) == '1') {

    $baby_names = $wpdb->get_results("SELECT DISTINCT `name`,`gender` FROM $baby_names_table WHERE `name` LIKE '".$search_param."%' ORDER BY `name` $orderstatus LIMIT $start_from,$results_per_page");

} else {

    $baby_names = $wpdb->get_results("SELECT DISTINCT `name`,`gender` FROM $baby_names_table WHERE `name` LIKE '%".$search_param."%' ORDER BY `name` $orderstatus LIMIT $start_from,$results_per_page");

}



        }











    }else {



        $pages = '1';



        if (isset($_GET['record'])) {

$limited = $_GET['record'];



        }else{

$limited = 20;



        }







        if (isset($_GET['orderBy'])) {

$orderstatus = $_GET['orderBy'];



        }else{

$orderstatus = 'ASC';



        }



        if(!empty($gender)) {

if(strlen($search_param) == '1') {

    $baby_names = $wpdb->get_results("SELECT DISTINCT `name`,`gender` FROM $baby_names_table WHERE `name` LIKE '".$search_param."%' AND `gender` = '$gender' ORDER BY `name` $orderstatus LIMIT ".$limited."");

} else {

    $baby_names = $wpdb->get_results("SELECT DISTINCT `name`,`gender` FROM $baby_names_table WHERE `name` LIKE '%".$search_param."%' AND `gender` = '$gender' ORDER BY `name` $orderstatus LIMIT ".$limited."");

}



        } else {

if(strlen($search_param) == '1') {

    $baby_names = $wpdb->get_results("SELECT DISTINCT `name`,`gender` FROM $baby_names_table WHERE `name` LIKE '".$search_param."%' ORDER BY `name` $orderstatus LIMIT ".$limited."");

} else {

    $baby_names = $wpdb->get_results("SELECT DISTINCT `name`,`gender` FROM $baby_names_table WHERE `name` LIKE '%".$search_param."%' ORDER BY `name` $orderstatus LIMIT ".$limited."");

}



        }



        //echo $wpdb->last_query;



    }



    return $baby_names;







}







function get_dogs_search_records($search_param,$gender = false) {



    global $wpdb;



    global $dog_names_table;







    if(!empty($_GET['pages'])){



        if (isset($_GET['record'])) {

$record = $_GET['record'];



        }else{

$record = 20;



        }



 //       $rowcount = $wpdb->get_var("SELECT COUNT(*) FROM $baby_names_table WHERE `letter` = '$LetterStartsWith' ORDER BY `name` ASC");



        if(strlen($search_param) == '1') {

$rowcount = $wpdb->get_results("SELECT DISTINCT `name` FROM $dog_names_table WHERE `name` LIKE '".$search_param."%' ORDER BY `name` ASC");



        } else {

$rowcount = $wpdb->get_results("SELECT DISTINCT `name` FROM $dog_names_table WHERE `name` LIKE '%".$search_param."%' ORDER BY `name` ASC");



        }



        $results_per_page = $record;







        $start_from = ($_GET['pages']-1) * $results_per_page;







        if (isset($_GET['orderBy'])) {

$orderstatus = $_GET['orderBy'];



        }else{

$orderstatus = 'DESC';



        }



        if(!empty($gender)) {

if(strlen($search_param) == '1') {

    $baby_names = $wpdb->get_results("SELECT DISTINCT `name`,`gender` FROM $dog_names_table WHERE `name` LIKE '".$search_param."%' AND `gender` = '$gender' ORDER BY `name` $orderstatus LIMIT $start_from,$results_per_page");

} else {

    $baby_names = $wpdb->get_results("SELECT DISTINCT `name`,`gender` FROM $dog_names_table WHERE `name` LIKE '%".$search_param."%' AND `gender` = '$gender' ORDER BY `name` $orderstatus LIMIT $start_from,$results_per_page");

}



        } else {

if(strlen($search_param) == '1') {

    $baby_names = $wpdb->get_results("SELECT DISTINCT `name` FROM $dog_names_table WHERE `name` LIKE '".$search_param."%' ORDER BY `name` $orderstatus LIMIT $start_from,$results_per_page");

} else {

    $baby_names = $wpdb->get_results("SELECT DISTINCT `name` FROM $dog_names_table WHERE `name` LIKE '%".$search_param."%' ORDER BY `name` $orderstatus LIMIT $start_from,$results_per_page");

}



        }











    }else {



        $pages = '1';



        if (isset($_GET['record'])) {

$limited = $_GET['record'];



        }else{

$limited = 20;



        }







        if (isset($_GET['orderBy'])) {

$orderstatus = $_GET['orderBy'];



        }else{

$orderstatus = 'ASC';



        }



        if(!empty($gender)) {

if(strlen($search_param) == '1') {

    $baby_names = $wpdb->get_results("SELECT DISTINCT `name`,`gender` FROM $dog_names_table WHERE `name` LIKE '".$search_param."%' AND `gender` = '$gender' ORDER BY `name` $orderstatus LIMIT ".$limited."");

} else {

    $baby_names = $wpdb->get_results("SELECT DISTINCT `name`,`gender` FROM $dog_names_table WHERE `name` LIKE '%".$search_param."%' AND `gender` = '$gender' ORDER BY `name` $orderstatus LIMIT ".$limited."");

}



        } else {

if(strlen($search_param) == '1') {

    $baby_names = $wpdb->get_results("SELECT DISTINCT `name` FROM $dog_names_table WHERE `name` LIKE '".$search_param."%' ORDER BY `name` $orderstatus LIMIT ".$limited."");

} else {

    $baby_names = $wpdb->get_results("SELECT DISTINCT `name` FROM $dog_names_table WHERE `name` LIKE '%".$search_param."%' ORDER BY `name` $orderstatus LIMIT ".$limited."");

}



        }







       // echo $wpdb->last_query;



    }



    return $baby_names;







}



function frontend_pagination_search($rowcountTotal,$pagination_url) {







    if (isset($_GET['record'])) {



        $limit = $_GET['record'];



    }else{



        $limit = 20;



    }







    $pages = ceil($rowcountTotal / $limit);



    if (isset($_GET['pages'])) {



        $currentpage = $_GET['pages'];



    }else{



        $currentpage = 1;



    }



    if (isset($_GET['record'])) {



        $recordpg = $_GET['record'];



    }else{



        $recordpg = 20;



    }



    if (isset($_GET['orderBy'])) {



        $orderbypg = $_GET['orderBy'];



    }else{



        $orderbypg = 'ASC';



    }



    if($rowcountTotal > $limit) {



        if($currentpage==1) {

$pagesprev = 1;

$next = $currentpage+1;



        } else {

$pagesprev = $currentpage-1;

$next = $currentpage+1;

if($next<=$pages){

    $next = $currentpage+1;

}else{

    $next = $currentpage;

}



        }



        if($currentpage!=1) {

$html .= "<div class='areaPagination'><a id='loadMoreperv' class='loadPrev' href=".$pagination_url.'&pages='.$pagesprev.'&orderBy='.$orderbypg.'&record='.$recordpg.">Poprzedni</a>";



        }



        if($currentpage!=$pages) {

$html .= "<a id='loadMore' class='loadNext' href=".$pagination_url.'&pages='.$next.'&orderBy='.$orderbypg.'&record='.$recordpg.">Kolejny</a></div>";



        }



        $html .= "<h4 class='pageCount'>Seans ".$currentpage." Z ".$pages." Strony</h4></div>";



    }



    return $html;



}



function frontend_pagination_dog_search($rowcountTotal,$pagination_url) {







    if (isset($_GET['record'])) {



        $limit = $_GET['record'];



    }else{



        $limit = 20;



    }







    $pages = ceil($rowcountTotal / $limit);



    if (isset($_GET['pages'])) {



        $currentpage = $_GET['pages'];



    }else{



        $currentpage = 1;



    }



    if (isset($_GET['record'])) {



        $recordpg = $_GET['record'];



    }else{



        $recordpg = 20;



    }



    if (isset($_GET['orderBy'])) {



        $orderbypg = $_GET['orderBy'];



    }else{



        $orderbypg = 'ASC';



    }



    if($rowcountTotal > $limit) {



        if($currentpage==1) {

$pagesprev = 1;

$next = $currentpage+1;



        } else {

$pagesprev = $currentpage-1;

$next = $currentpage+1;

if($next<=$pages){

    $next = $currentpage+1;

}else{

    $next = $currentpage;

}



        }



        if($currentpage!=1) {

$html .= "<div class='areaPagination'><a id='loadMoreperv' class='loadPrev' href=".$pagination_url.'&pages='.$pagesprev.'&orderBy='.$orderbypg.'&record='.$recordpg.">Poprzedni</a>";



        }



        if($currentpage!=$pages) {

$html .= "<a id='loadMore' class='loadNext' href=".$pagination_url.'&pages='.$next.'&orderBy='.$orderbypg.'&record='.$recordpg.">Kolejny</a></div>";



        }



        $html .= "<h4 class='pageCount'>Seans ".$currentpage." Z ".$pages." Strony</h4></div>";



    }



    return $html;



}







//function frontend_pagination($rowcountTotal,$pagination_url) {



function frontend_pagination($rowcountTotal,$pages,$category_id,$gender_att) {



    $limit = 20;



    $totalpages = ceil($rowcountTotal / $limit);



    $currentpage = $pages;



    $recordpg = 20;



    $orderbypg = 'ASC';



    if($rowcountTotal > $limit) {



        if($currentpage==1) {

$pagesprev = 1;

$next = $currentpage+1;



        } else {

$pagesprev = $currentpage-1;

$next = $currentpage+1;

if($next<=$totalpages){

    $next = $currentpage+1;

}else{

    $next = $currentpage;

}



        }



        if($currentpage!=1) {

$html .= "<div class='areaPagination'><a id='loadMoreperv' class='loadPrev' onclick=cvf_load_all_posts($pagesprev,$category_id,'$gender_att') href='javascript:void(0);'>Poprzedni</a>";



        }



        if($currentpage!=$totalpages) {

$html .= "<a id='loadMore' class='loadNext' onclick=cvf_load_all_posts($next,$category_id,'$gender_att') href='javascript:void(0);'>Kolejny</a></div>";



        }



        $html .= "<h4 class='pageCount'>Seans ".$currentpage." Z ".$totalpages." Strony</h4></div>";



    }



    return $html;



}







function frontend_dog_pagination($rowcountTotal,$pages,$category_id) {



    $limit = 20;



    $totalpages = ceil($rowcountTotal / $limit);



    $currentpage = $pages;



    $recordpg = 20;



    $orderbypg = 'ASC';



    if($rowcountTotal > $limit) {



        if($currentpage==1) {

$pagesprev = 1;

$next = $currentpage+1;



        } else {

$pagesprev = $currentpage-1;

$next = $currentpage+1;

if($next<=$totalpages){

    $next = $currentpage+1;

}else{

    $next = $currentpage;

}



        }



        if($currentpage!=1) {

$html .= "<div class='areaPagination'><a id='loadMoreperv' class='loadPrev' onclick=cvf_load_all_posts_dogs($pagesprev,$category_id) href='javascript:void(0);'>Poprzedni</a>";



        }



        if($currentpage!=$totalpages) {

$html .= "<a id='loadMore' class='loadNext' onclick=cvf_load_all_posts_dogs($next,$category_id) href='javascript:void(0);'>Kolejny</a></div>";



        }



        $html .= "<h4 class='pageCount'>Seans ".$currentpage." Z ".$totalpages." Strony</h4></div>";



    }



    return $html;



}







function frontend_pagination_letter($rowcountTotal,$pages,$LetterStartsWith,$gender_att) {



    $limit = 20;



    $totalpages = ceil($rowcountTotal / $limit);



    $currentpage = $pages;



    $recordpg = 20;



    $orderbypg = 'ASC';



    if($rowcountTotal > $limit) {



        if($currentpage==1) {

$pagesprev = 1;

$next = $currentpage+1;



        } else {

$pagesprev = $currentpage-1;

$next = $currentpage+1;

if($next<=$totalpages){

    $next = $currentpage+1;

}else{

    $next = $currentpage;

}



        }



        if($currentpage!=1) {

$html .= "<div class='areaPagination'><a id='loadMoreperv' class='loadPrev' onclick=load_letters($pagesprev,'$LetterStartsWith','$gender_att') href='javascript:void(0);'>Poprzedni</a>";



        }



        if($currentpage!=$totalpages) {

$html .= "<a id='loadMore' class='loadNext' onclick=load_letters($next,'$LetterStartsWith','$gender_att') href='javascript:void(0);'>Kolejny</a></div>";



        }



        $html .= "<h4 class='pageCount'>Seans ".$currentpage." Z ".$totalpages." Strony</h4></div>";



    }



    return $html;



}







function frontend_pagination_letter_dogs($rowcountTotal,$pages,$LetterStartsWith) {



    $limit = 20;



    $totalpages = ceil($rowcountTotal / $limit);



    $currentpage = $pages;



    $recordpg = 20;



    $orderbypg = 'ASC';



    if($rowcountTotal > $limit) {



        if($currentpage==1) {

$pagesprev = 1;

$next = $currentpage+1;



        } else {

$pagesprev = $currentpage-1;

$next = $currentpage+1;

if($next<=$totalpages){

    $next = $currentpage+1;

}else{

    $next = $currentpage;

}



        }



        if($currentpage!=1) {

$html .= "<div class='areaPagination'><a id='loadMoreperv' class='loadPrev' onclick=load_letters_dogs($pagesprev,'$LetterStartsWith') href='javascript:void(0);'>Poprzedni</a>";



        }



        if($currentpage!=$totalpages) {

$html .= "<a id='loadMore' class='loadNext' onclick=load_letters_dogs($next,'$LetterStartsWith') href='javascript:void(0);'>Kolejny</a></div>";



        }



        $html .= "<h4 class='pageCount'>Seans ".$currentpage." Z ".$totalpages." Strony</h4></div>";



    }



    return $html;



}











add_action( 'wp_ajax_pagination_data', 'pagination_data' );



add_action( 'wp_ajax_nopriv_pagination_data', 'pagination_data' );



function pagination_data() {



    global $wpdb;



    global $baby_names_table;



    $pages = $_POST['page'];



    $gender = $_POST['gender_att'];



    $category_id = $_POST['catID'];



    if($pages > 1) {



        $record = 20;



        $rowcount = $wpdb->get_var("SELECT COUNT(*) FROM $baby_names_table WHERE `directory` = $category_id ORDER BY `name` ASC");



        $results_per_page = $record;



        $start_from = ($pages-1) * $results_per_page;



        $orderstatus = 'DESC';



        if(!empty($gender)) {

$baby_names = $wpdb->get_results("SELECT * FROM $baby_names_table WHERE `directory` = $category_id AND `gender` = '$gender' ORDER BY `name` $orderstatus LIMIT $start_from,$results_per_page");



        } else {

$baby_names = $wpdb->get_results("SELECT * FROM $baby_names_table WHERE `directory` = $category_id ORDER BY `name` $orderstatus LIMIT $start_from,$results_per_page");



        }



       $catResultHtml = "";



        if(count($baby_names) > 0) {

$catResultHtml .= "<div id='baby-name-results-container' class='margin-top-30'>";

$catResultHtml .="<div class='baby-name-tool-title'>";

$catResultHtml .= "<h1 class='baby-name-tool-title'>";

if(count($category_name) > 0):

    $catResultHtml .= "Wyszukiwania Dla Kategoria - ".$category_name[0]->name;

    endif;

$catResultHtml .= "</h1></div>";

$catResultHtml .= "<div class='baby-name-list'>";

$catResultHtml .= "<table class='table'>";

$catResultHtml .= "<thead>";

$catResultHtml .="<tr>";

$catResultHtml .="<th>Nazwa</th>";

$catResultHtml .="<th>Gen</th></tr></thead>";

$catResultHtml .="<tbody>";

foreach($baby_names as $bnames) {

$catResultHtml .="<tr>";

$catResultHtml .= "<td>";

$catResultHtml .= $bnames->name;

$catResultHtml .= "</td>";

if($_GET['boy'] == 'boy') {

    $catResultHtml .="<td>";

    $catResultHtml .= "<i class='fa fa-mars fa-2x' aria-hidden='true'></i></td>";

        } elseif($_GET['girl'] == 'girl') {

            $catResultHtml .= "<td><i class='fa fa-venus fa-2x' aria-hidden='true'></i></td>";

        } else {

            if($bnames->gender == 'boy') {

                $catResultHtml .="<td><i class='fa fa-mars fa-2x' aria-hidden='true'></i></td>";

            } elseif($bnames->gender == 'girl') {

                $catResultHtml .="<td><i class='fa fa-venus fa-2x' aria-hidden='true'></i></td>";

            }

        }





        $catResultHtml .="</tr>";

}

$catResultHtml .="</tbody></table></div></div>";

$catResultHtml .= "<div id='pagi_data'>";

//$catResultHtml .= frontend_pagination($rowcountTotal,$pages,$category_id,$gender_att);

// new code

if($gender == 'boy') {

    $rowcountTotal = $wpdb->get_var("SELECT COUNT(*) FROM $baby_names_table WHERE `directory` = $category_id AND `gender` = '$gender' ORDER BY `name` ASC");

} elseif($gender == 'girl') {

    $rowcountTotal = $wpdb->get_var("SELECT COUNT(*) FROM $baby_names_table WHERE `directory` = $category_id AND `gender` = '$gender' ORDER BY `name` ASC");

}

$limit = 20;

$totalpages = ceil($rowcountTotal / $limit);

$currentpage = $pages;

$recordpg = 20;

$orderbypg = 'ASC';

if($rowcountTotal > $limit) {

    if($currentpage==1) {

        $pagesprev = 1;

        $next = $currentpage+1;

    } else {

        $pagesprev = $currentpage-1;

        $next = $currentpage+1;

        if($next<=$totalpages){

            $next = $currentpage+1;

        }else{

            $next = $currentpage;

        }

    }

    if($currentpage!=1) {

        $catResultHtml .= "<div class='areaPagination'><a id='loadMoreperv' class='loadPrev' onclick=cvf_load_all_posts($pagesprev,$category_id,'$gender') href='javascript:void(0);'>Poprzedni</a>";

    }

    if($currentpage!=$totalpages) {

        $catResultHtml .= "<a id='loadMore' class='loadNext' onclick=cvf_load_all_posts($next,$category_id,'$gender') href='javascript:void(0);'>Kolejny</a></div>";

    }

    $catResultHtml .= "<h4 class='pageCount'>Seans ".$currentpage." Z ".$totalpages." Strony</h4></div>";

}

// new code





$catResultHtml .= "</div>";



        } else {

$catResultHtml .= "<div id='baby-name-results-container' class='margin-top-30'>";

$catResultHtml .= "<div class='margin-bottom-20'>";

$catResultHtml .= "<div class='baby-name-tool-title'>";

$catResultHtml .= "<h1 class='baby-name-tool-title'>";

if(count($category_name) > 0):

    $catResultHtml .="Nie znaleziono wyników dla ".$category_name[0]->name.' Category';

endif;





$catResultHtml .="</h1>";

$catResultHtml .="</div>";

$catResultHtml .="</div>";

$catResultHtml .="</div>";



        }



        echo $catResultHtml;



    } else {



       ?>



        <script>



        var catID =<?php echo $category_id;?>;



        var gen = '<?php echo $gender;?>';

catAjax(catID,gen,1);



        </script>



    <?php    }



    exit();



}


add_action( 'wp_ajax_pagination_data_dogs', 'pagination_data_dogs' );



add_action( 'wp_ajax_nopriv_pagination_data_dogs', 'pagination_data_dogs' );



function pagination_data_dogs() {



    global $wpdb;



    global $dog_names_table;



    global $dog_category_table;



    $pages = $_POST['page'];



    //$gender = $_POST['gender_att'];



    $category_id = $_POST['catID'];



    if($pages > 1) {



        $record = 20;



        $rowcount = $wpdb->get_var("SELECT COUNT(*) FROM $dog_names_table WHERE `directory` = $category_id ORDER BY `name` ASC");



        $results_per_page = $record;



        $start_from = ($pages-1) * $results_per_page;



       // $orderstatus = 'DESC';



        $orderstatus = 'ASC';



        if(!empty($gender)) {

$baby_names = $wpdb->get_results("SELECT * FROM $dog_names_table WHERE `directory` = $category_id AND `gender` = '$gender' ORDER BY `name` $orderstatus LIMIT $start_from,$results_per_page");



        } else {

$baby_names = $wpdb->get_results("SELECT * FROM $dog_names_table WHERE `directory` = $category_id ORDER BY `name` $orderstatus LIMIT $start_from,$results_per_page");



        }



       $catResultHtml = "";



       $category_name = $wpdb->get_results("SELECT `name` FROM $dog_category_table WHERE `id` = $category_id");



        if(count($baby_names) > 0) {

$catResultHtml .= "<div id='baby-name-results-container' class='margin-top-30'>";

$catResultHtml .="<div class='baby-name-tool-title'>";

$catResultHtml .= "<h1 class='baby-name-tool-title'>";

if(count($category_name) > 0):

    $catResultHtml .= "Wyszukiwania Dla Kategoria - ".$category_name[0]->name;

    endif;

$catResultHtml .= "</h1></div>";

$catResultHtml .= "<div class='baby-name-list'>";

$catResultHtml .= "<table class='table'>";

$catResultHtml .= "<thead>";

$catResultHtml .="<tr>";

$catResultHtml .="<th>Nazwa</th>";



         //   $catResultHtml .="<th>Gen</th></tr></thead>";

$catResultHtml .="<tbody>";

foreach($baby_names as $bnames) {

$catResultHtml .="<tr>";

$catResultHtml .= "<td>";

$catResultHtml .= $bnames->name;

$catResultHtml .= "</td>";



           /* if($_GET['boy'] == 'boy') {

    $catResultHtml .="<td>";

    $catResultHtml .= "<i class='fa fa-mars fa-2x' aria-hidden='true'></i></td>";

        } elseif($_GET['girl'] == 'girl') {

            $catResultHtml .= "<td><i class='fa fa-venus fa-2x' aria-hidden='true'></i></td>";

        } else {

            if($bnames->gender == 'boy') {

                $catResultHtml .="<td><i class='fa fa-mars fa-2x' aria-hidden='true'></i></td>";

            } elseif($bnames->gender == 'girl') {

                $catResultHtml .="<td><i class='fa fa-venus fa-2x' aria-hidden='true'></i></td>";

            }

        } */





        $catResultHtml .="</tr>";

}

$catResultHtml .="</tbody></table></div></div>";

$catResultHtml .= "<div id='pagi_data'>";

// new code



          /*  if($gender == 'boy') {

    $rowcountTotal = $wpdb->get_var("SELECT COUNT(*) FROM $baby_names_table WHERE `directory` = $category_id AND `gender` = '$gender' ORDER BY `name` ASC");

} elseif($gender == 'girl') {

    $rowcountTotal = $wpdb->get_var("SELECT COUNT(*) FROM $baby_names_table WHERE `directory` = $category_id AND `gender` = '$gender' ORDER BY `name` ASC");

} */

$rowcountTotal = $wpdb->get_var("SELECT COUNT(*) FROM $dog_names_table WHERE `directory` = $category_id ORDER BY `name` ASC");

$limit = 20;

$totalpages = ceil($rowcountTotal / $limit);

$currentpage = $pages;

$recordpg = 20;

$orderbypg = 'ASC';

if($rowcountTotal > $limit) {

    if($currentpage==1) {

        $pagesprev = 1;

        $next = $currentpage+1;

    } else {

        $pagesprev = $currentpage-1;

        $next = $currentpage+1;

        if($next<=$totalpages){

            $next = $currentpage+1;

        }else{

            $next = $currentpage;

        }

    }

    if($currentpage!=1) {

        $catResultHtml .= "<div class='areaPagination'><a id='loadMoreperv' class='loadPrev' onclick=cvf_load_all_posts_dogs($pagesprev,$category_id,'$gender') href='javascript:void(0);'>Poprzedni</a>";

    }

    if($currentpage!=$totalpages) {

        $catResultHtml .= "<a id='loadMore' class='loadNext' onclick=cvf_load_all_posts_dogs($next,$category_id,'$gender') href='javascript:void(0);'>Kolejny</a></div>";

    }

    $catResultHtml .= "<h4 class='pageCount'>Seans ".$currentpage." Z ".$totalpages." Strony</h4></div>";

}

// new code





$catResultHtml .= "</div>";



        } else {

$catResultHtml .= "<div id='baby-name-results-container' class='margin-top-30'>";

$catResultHtml .= "<div class='margin-bottom-20'>";

$catResultHtml .= "<div class='baby-name-tool-title'>";

$catResultHtml .= "<h1 class='baby-name-tool-title'>";

if(count($category_name) > 0):

    $catResultHtml .="Nie znaleziono wyników dla ".$category_name[0]->name.' Category';

endif;





$catResultHtml .="</h1>";

$catResultHtml .="</div>";

$catResultHtml .="</div>";

$catResultHtml .="</div>";



        }



        echo $catResultHtml;



    } else {



       ?>



        <script>



        var catID =<?php echo $category_id;?>;



        var gen = '<?php echo $gender;?>';



        dogCatAjax(catID,1);



        </script>



    <?php    }



    exit();



}











add_action( 'wp_ajax_pagination_data_letter_dogs', 'pagination_data_letter_dogs' );



add_action( 'wp_ajax_nopriv_pagination_data_letter_dogs', 'pagination_data_letter_dogs' );



function pagination_data_letter_dogs() {



    global $wpdb;



    global $dog_names_table;



    $pages = $_POST['page'];



  //  $gender = $_POST['gender_att'];



    $LetterStartsWith = $_POST['LetterStartsWith'];







    if($pages > 1){



          $record = 20;



          $rowcount = $wpdb->get_var("SELECT COUNT(*) FROM $dog_names_table WHERE `letter` = '$LetterStartsWith' ORDER BY `name` ASC");



          $results_per_page = $record;







        //  $start_from = ($_GET['pages']-1) * $results_per_page;



          $start_from = ($pages-1) * $results_per_page;



         // $orderstatus = 'DESC';



          $orderstatus = 'ASC';



          if(!empty($gender)) {

$letter_search_names = $wpdb->get_results("SELECT DISTINCT `name`,`gender` FROM $dog_names_table WHERE `letter` = '$LetterStartsWith' AND `gender` = '$gender' ORDER BY `name` $orderstatus LIMIT $start_from,$results_per_page");

} else {

    $letter_search_names = $wpdb->get_results("SELECT DISTINCT `name` FROM $dog_names_table WHERE `letter` = '$LetterStartsWith' ORDER BY `name` $orderstatus LIMIT $start_from,$results_per_page");

}

if(count($letter_search_names) > 0) {

    $ResultHtml .="<div id='baby-name-results-container' class='margin-top-30'>";

    $ResultHtml .= "<div class='baby-name-tool-title'>";

    $ResultHtml .= "<h1 class='baby-name-tool-title'>";

    $ResultHtml .= "Nume de copii care incep cu - ".$LetterStartsWith;

    $ResultHtml .= "</h1>";

    $ResultHtml .=  "</div>";

    $ResultHtml .= "<div class='baby-name-list'>";

    $ResultHtml .=  "<table class='table'>";

    $ResultHtml .= "<thead><tr><th>Nazwa</th></tr></thead><tbody>";

     foreach($letter_search_names as $bnames) {

        $ResultHtml .="<tr>";

        $ResultHtml .=  "<td>";

        $ResultHtml .= $bnames->name;

        $ResultHtml .= "</td>";

       /*  if($_GET['boy'] == 'boy') {

            $ResultHtml .=  "<td><i class='fa fa-mars fa-2x' aria-hidden='true'></i></td>";

                            } elseif($_GET['girl'] == 'girl') {

                                $ResultHtml .= "<td><i class='fa fa-venus fa-2x' aria-hidden='true'></i></td>";

                            } else {

                                if($bnames->gender == 'boy') {

                                    $ResultHtml .= "<td><i class='fa fa-mars fa-2x' aria-hidden='true'></i></td>";

                                } elseif($bnames->gender == 'girl') {

                                    $ResultHtml .=  "<td><i class='fa fa-venus fa-2x' aria-hidden='true'></i></td>";

                                }

                            } */

                            $ResultHtml .= "</tr>";

                        }

                        $ResultHtml .= "</tbody>";

                        $ResultHtml .= "</table>";

                        $ResultHtml .= "</div>";

                        $ResultHtml .= "</div>";

                  $catResultHtml .= "<div id='pagi_data'>";

                  //$catResultHtml .= frontend_pagination($rowcountTotal,$pages,$category_id,$gender_att);

                  // new code

                 /* if($gender == 'boy') {

                    $resultSet = $wpdb->get_results("SELECT DISTINCT `name`,`gender` FROM $dog_names_table WHERE `letter` = '$LetterStartsWith' AND `gender` = '$gender' ORDER BY `name` ASC");

                    $rowcountTotal = $wpdb->num_rows;

                } elseif($gender == 'girl') {

                    $resultSet = $wpdb->get_results("SELECT DISTINCT `name`,`gender` FROM $dog_names_table WHERE `letter` = '$LetterStartsWith' AND `gender` = '$gender' ORDER BY `name` ASC");

                    $rowcountTotal = $wpdb->num_rows;

                } */

                $resultSet = $wpdb->get_results("SELECT DISTINCT `name` FROM $dog_names_table WHERE `letter` = '$LetterStartsWith'  ORDER BY `name` ASC");

                $rowcountTotal = $wpdb->num_rows;

                  $limit = 20;

                  $totalpages = ceil($rowcountTotal / $limit);

                  $currentpage = $pages;

                  $recordpg = 20;

                  $orderbypg = 'ASC';

                  if($rowcountTotal > $limit) {

                      if($currentpage==1) {

                          $pagesprev = 1;

                          $next = $currentpage+1;

                      } else {

                          $pagesprev = $currentpage-1;

                          $next = $currentpage+1;

                          if($next<=$totalpages){

                              $next = $currentpage+1;

                          }else{

                              $next = $currentpage;

                          }

                      }

                      if($currentpage!=1) {

                          $ResultHtml .= "<div class='areaPagination'><a id='loadMoreperv' class='loadPrev' onclick=load_letters_dogs($pagesprev,'$LetterStartsWith') href='javascript:void(0);'>Poprzedni</a>";

                      }

                      if($currentpage!=$totalpages) {

                          $ResultHtml .= "<a id='loadMore' class='loadNext' onclick=load_letters_dogs($next,'$LetterStartsWith') href='javascript:void(0);'>Kolejny</a></div>";

                      }

                      $ResultHtml .= "<h4 class='pageCount'>Seans ".$currentpage." Z ".$totalpages." Strony</h4></div>";

                  }

                  // new code





                  $ResultHtml .= "</div>";



      } else {



        $ResultHtml .= "<div id='baby-name-results-container' class='margin-top-30'>";



        $ResultHtml .= "<div class='margin-bottom-20'>";



        $ResultHtml .= "<div class='baby-name-tool-title'>";



        $ResultHtml .= "<h1 class='baby-name-tool-title'>";



        $ResultHtml .= "Nie znaleziono wyników dla ".$LetterStartsWith;



        $ResultHtml .= "</h1></div></div></div>";



          }



      echo $ResultHtml;



    } else {



        ?>



         <script>



         var letter ='<?php echo $LetterStartsWith;?>';



         var gen = '<?php echo $gender;?>';



         letterClickDogs(letter,1);



         </script>



     <?php  }



     exit();



}