jQuery(document).ready(function() {


    jQuery("#searhFormButton").click(function() {


        var searchTerm = jQuery("#searchTerm").val();


        jQuery("#searchTerm").css("border","");


        if(searchTerm == ''){


            jQuery("#searchTerm").css("border","2px solid red");


            return false;


        }


    });


});


function catAjax(val,gender_att,page) {


    jQuery(function() {


        jQuery.ajax({


            url: admin_ajx_url,


            type: "POST",


            data : {action : 'cat_ajax',catID: val,gender_att:gender_att,pages:page},


            beforeSend: function() {


                jQuery('#overlay').css("visibility", "visible");


            },


            success: function( response ) {


                    jQuery("#categoryContainer").html(response);


                    jQuery('.search-container').empty();


                    jQuery('#searchTerm').val('');


                    var uri = window.location.toString();


                    if (uri.indexOf("?") > 0) {


                        var clean_uri = uri.substring(0, uri.indexOf("?"));


                        window.history.replaceState({}, document.title, clean_uri);


                    }


            },


            complete: function(){


                jQuery('#overlay').css("visibility", "hidden");


                jQuery('html, body').animate({


                    scrollTop: jQuery("#baby-name-results-container").offset().top


                }, 0);


               // jQuery('body').scrollTo('#baby-name-results-container');


              }


       })


    })


}





function dogCatAjax(val,page) {


    jQuery(function() {


        jQuery.ajax({


            url: admin_ajx_url,


            type: "POST",


            data : {action : 'dogCat_ajax',catID: val,pages:page},


            beforeSend: function() {


                jQuery('#overlay').css("visibility", "visible");


            },


            success: function( response ) {


                    jQuery("#categoryContainer").html(response);


                    jQuery('.search-container').empty();


                    jQuery('#searchTerm').val('');


                    var uri = window.location.toString();


                    if (uri.indexOf("?") > 0) {


                        var clean_uri = uri.substring(0, uri.indexOf("?"));


                        window.history.replaceState({}, document.title, clean_uri);


                    }


            },


            complete: function(){


                jQuery('#overlay').css("visibility", "hidden");


               /* jQuery('html, body').animate({


                    scrollTop: jQuery("#baby-name-results-container").offset().top


                }, 0); */


               // jQuery('body').scrollTo('#baby-name-results-container');


               jQuery('html, body').animate({scrollTop: '0px'}, 0);


              }


       })


    })


}





function letterClick(val,gender_att,page) {


    jQuery(function() {


        jQuery.ajax({


            url: admin_ajx_url,


            type: "POST",


            data : {action : 'letter_ajax',letter: val,gender_att:gender_att,pages:page},


            beforeSend: function() {


                jQuery('#overlay').css("visibility", "visible");


            },


            success: function( response ) {


                    jQuery("#categoryContainer").html(response);


                    jQuery('.search-container').empty();


                    jQuery('#searchTerm').val('');


                    var uri = window.location.toString();


                    if (uri.indexOf("?") > 0) {


                        var clean_uri = uri.substring(0, uri.indexOf("?"));


                        window.history.replaceState({}, document.title, clean_uri);


                    }


            },


            complete: function(){


                jQuery('#overlay').css("visibility", "hidden");


                jQuery('html, body').animate({


                    scrollTop: jQuery("#baby-name-results-container").offset().top


                }, 0);


              }


       })


    })





}





function letterClickDogs(val,page) {


    jQuery(function() {


        jQuery.ajax({


            url: admin_ajx_url,


            type: "POST",


            data : {action : 'letter_ajax_dogs',letter: val,pages:page},


            beforeSend: function() {


                jQuery('#overlay').css("visibility", "visible");


            },


            success: function( response ) {


                    jQuery("#categoryContainer").html(response);


                    jQuery('.search-container').empty();


                    jQuery('#searchTerm').val('');


                    var uri = window.location.toString();


                    if (uri.indexOf("?") > 0) {


                        var clean_uri = uri.substring(0, uri.indexOf("?"));


                        window.history.replaceState({}, document.title, clean_uri);


                    }


            },


            complete: function(){


                jQuery('#overlay').css("visibility", "hidden");


                jQuery('html, body').animate({


                    scrollTop: jQuery("#baby-name-results-container").offset().top


                }, 0);


              }


       })


    })





}





function cvf_load_all_posts(page,category_id,gender_att){


    jQuery(function() {


        jQuery.ajax({


            url: admin_ajx_url,


            type: "POST",


            data : {action : 'pagination_data',page: page,catID: category_id,gender_att:gender_att},


            beforeSend: function(){


                jQuery('#overlay').css("visibility", "visible");


            },


            success: function( response ) {


                jQuery("#categoryContainer").html(response);


            },


            complete: function(){


                jQuery('#overlay').css("visibility", "hidden");


                jQuery('html, body').animate({


                    scrollTop: jQuery("#baby-name-results-container").offset().top


                }, 0);


              }


         })


    })


}





function cvf_load_all_posts_dogs(page,category_id){


    jQuery(function() {


        jQuery.ajax({


            url: admin_ajx_url,


            type: "POST",


            data : {action : 'pagination_data_dogs',page: page,catID: category_id},


            beforeSend: function(){


                jQuery('#overlay').css("visibility", "visible");


            },


            success: function( response ) {


                jQuery("#categoryContainer").html(response);


            },


            complete: function(){


                jQuery('#overlay').css("visibility", "hidden");


              /*  jQuery('html, body').animate({


                    scrollTop: jQuery("#baby-name-results-container").offset().top


                }, 0); */


              //  jQuery('body').scrollTo('#baby-name-results-container');


              jQuery('html, body').animate({scrollTop: '0px'}, 0);


              }


         })


    })


}





function load_letters(page,letter,gender_att) {


    jQuery(function() {


        jQuery.ajax({


            url: admin_ajx_url,


            type: "POST",


            data : {action : 'pagination_data_letter',page: page,LetterStartsWith: letter,gender_att:gender_att},


            beforeSend: function(){


                jQuery('#overlay').css("visibility", "visible");


            },


            success: function( response ) {


                jQuery("#categoryContainer").html(response);


            },


            complete: function(){


                jQuery('#overlay').css("visibility", "hidden");


                jQuery('html, body').animate({


                    scrollTop: jQuery("#baby-name-results-container").offset().top


                }, 0);


              }


         })


    })


}





function load_letters_dogs(page,letter) {


    jQuery(function() {


        jQuery.ajax({


            url: admin_ajx_url,


            type: "POST",


            data : {action : 'pagination_data_letter_dogs',page: page,LetterStartsWith: letter},


            beforeSend: function(){


                jQuery('#overlay').css("visibility", "visible");


            },


            success: function( response ) {


                jQuery("#categoryContainer").html(response);


            },


            complete: function(){


                jQuery('#overlay').css("visibility", "hidden");


                jQuery('html, body').animate({


                    scrollTop: jQuery("#baby-name-results-container").offset().top


                }, 0);


              }


         })


    })


}


