<?php
function areaInMetersSquaure($l,$lUnit,$b,$bUnit,$h,$hUnit,$noOfExternalWalls,$insulation_typeVal,$floor_level,$custom_u_value,$Ad_modeWindows,$Ad_modeDoors) {
	//echo $l;
	//echo $lUnit;
	$lenInMeter = convertDimensionToMeter($l,$lUnit);
	$breadthInMeter= convertDimensionToMeter($b,$bUnit);
	$heightInMeter=convertDimensionToMeter($h,$hUnit);
	//echo $lenInMeter;exit;
	if($noOfExternalWalls==1){
	    $areaOfExtWallByNumber = $lenInMeter * $heightInMeter;
	} else if($noOfExternalWalls==2){
	    $areaOfExtWallByNumber = ($lenInMeter * $heightInMeter)+ ($breadthInMeter *$heightInMeter);
	} else if($noOfExternalWalls==3){
	  //  $areaOfExtWallByNumber = ($lenInMeter * $heightInMeter)+ ($breadthInMeter *$heightInMeter);
	    $areaOfExtWallByNumber = ($lenInMeter * $heightInMeter)+ ($breadthInMeter *$heightInMeter) + ($breadthInMeter *$heightInMeter);
	} else if($noOfExternalWalls==4){
		$areaOfExtWallByNumber=2 * $heightInMeter*($lenInMeter + $breadthInMeter);
		//echo $areaOfExtWallByNumber;exit;
	}
//	echo $areaOfExtWallByNumber;exit;
	return $areaOfExtWallByNumber;
}

function convertDimensionToMeter($dimension,$dimensionUnit) {

//	$dimensionInMeter;
	if($dimensionUnit=='mm') {
		$dimensionInMeter=$dimension * 0.001;
	}   else if($dimensionUnit=='cm') {
		$dimensionInMeter=$dimension * .01;
	} else if($dimensionUnit=='m'){
		$dimensionInMeter=$dimension;
	}else if($dimensionUnit=='km'){
		$dimensionInMeter=$dimension * 1000;
	}else if($dimensionUnit=='in'){
		$dimensionInMeter=$dimension * 0.0254;
	}else if($dimensionUnit=='ft'){
		$dimensionInMeter=$dimension * 0.3048;
	}else if($dimensionUnit=='yd'){
		$dimensionInMeter=$dimension * 0.9144;
	}else if($dimensionUnit=='mi'){
		$dimensionInMeter=$dimension * 1609.34;
	}

	//Add more cases Kiran
	return $dimensionInMeter;

	}

	function totalHeatLoss($l,$lUnit,$b,$bUnit,$h,$hUnit,$noOfExternalWalls,$insulation_typeVal,$floor_level,$custom_u_value,$Ad_modeWindows,$Ad_modeDoors){
		if($custom_u_value != '') {
			$insulation_typeVal = $custom_u_value;
		}
		$heatLossThroughExtWalls = calculateHeatLossThroughExtWalls($l,$lUnit,$b,$bUnit,$h,$hUnit,$noOfExternalWalls,$insulation_typeVal);
	//	echo $heatLossThroughExtWalls;exit;
		$heatLossThroughCelingOrFloor = calculateHeatLossThroughCeilingOrFloor($l,$lUnit,$b,$bUnit,$floor_level);
		return ($heatLossThroughExtWalls + $heatLossThroughCelingOrFloor);
	}

	function calculateHeatLossThroughExtWalls($l,$lUnit,$b,$bUnit,$h,$hUnit,$noOfExternalWalls,$insulation_typeVal){
		$lenInMeter = convertDimensionToMeter($l,$lUnit);
		$breadthInMeter= convertDimensionToMeter($b,$bUnit);
		$heightInMeter=convertDimensionToMeter($h,$hUnit);
		//echo $lenInMeter;exit;
		if($noOfExternalWalls==1){
		$areaOfExtWallByNumber = $lenInMeter * $heightInMeter;
		} else if($noOfExternalWalls==2){
		$areaOfExtWallByNumber = ($lenInMeter * $heightInMeter)+ ($breadthInMeter *$heightInMeter);
		} else if($noOfExternalWalls==3){
		//  $areaOfExtWallByNumber = ($lenInMeter * $heightInMeter)+ ($breadthInMeter *$heightInMeter);
		$areaOfExtWallByNumber = ($lenInMeter * $heightInMeter)+ ($breadthInMeter *$heightInMeter) + ($breadthInMeter *$heightInMeter);
		} else if($noOfExternalWalls==4){
		$areaOfExtWallByNumber=2 * $heightInMeter*($lenInMeter + $breadthInMeter);
		}
		// echo $areaOfExtWallByNumber;exit;
		return ($areaOfExtWallByNumber * $insulation_typeVal);
	}

	function calculateHeatLossThroughCeilingOrFloor($l,$lUnit,$b,$bUnit,$floor_level){
		$lenInMeter = convertDimensionToMeter($l,$lUnit);
		$breadthInMeter= convertDimensionToMeter($b,$bUnit);
		$heatLossThroughCeilingOrFloor=0;

		if($floor_level=='ground'){
			$heatLossThroughCeilingOrFloor=$lenInMeter * $breadthInMeter * 1; // for now these values are constant can make dynamic in case these u values changes in future.
		} else if($floor_level=='top'){
			$heatLossThroughCeilingOrFloor=$lenInMeter * $breadthInMeter * .7; // for now these values are constant can make dynamic in case these u values changes in future.
		}
		return $heatLossThroughCeilingOrFloor;
	}

	// Power Method //
	function calculatePower($heat_loss,$ambientTemp,$ambientTempU,$internalTemp,$internalTempU) {
		$ambientTempInKelvin = convertTempInKelvin($ambientTemp,$ambientTempU);
		//$ambientTempInKelvin = convertTempInKelvin('-20','C');
		//$internalTempInKelvin = convertTempInKelvin('20','C');
		$internalTempInKelvin = convertTempInKelvin($internalTemp,$internalTempU);
		$tempDifference =  $internalTempInKelvin - $ambientTempInKelvin;
		//echo $tempDifference;exit;
		$powerRequired = $tempDifference * $heat_loss;

		return $powerRequired;

	}

	function convertTempInKelvin($temp,$tempUnit) {
		//echo $temp;exit;
		if($tempUnit == 'K') {
			$tempInkelvin = $temp;
		//	$tempIncl = $temp * -272.15;
		} else if($tempUnit == 'C') {
			$tempInkelvin = $temp + 274.14;
			//$tempInkelvin = $temp * 274.15;
			//$tempIncl = $temp;
			$tempInkelvin = $temp;
		} else if($tempUnit == 'F') {
			// echo "hhh";exit;
			$tempInkelvin = ($temp -  32) * 5/9 + 273.15;
			//$tempInkelvin = $temp - ( 33.800072);
			//$tempInkelvin = $temp;
		}
//echo $tempInkelvin;exit;
		 return $tempInkelvin;
		//return $tempIncl;
	}
	// Power Method //
?>