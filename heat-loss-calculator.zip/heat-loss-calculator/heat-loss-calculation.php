<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
/*
Plugin Name: Heat Loss Calculator
Version: 1.3
Author: Dev
*/


// function that runs when shortcode is called
//require_once dirname( __FILE__ ) . '/constants.php';
require_once dirname( __FILE__ ) . '/helpers.php';
function heat_loss_calculator() {
ob_start();
?>
<style>
/* .advance-setting-area {display:none;} */
</style>
<link type="text/css" rel="stylesheet" href="<?php echo plugins_url(); ?>/heat-loss-calculator/css/heat-style.css?v=<?php echo mt_rand();?>">
<script>var admin_ajx_url = "<?php echo admin_url('admin-ajax.php'); ?>";</script>
<div class="Calculator">
	<div class="Calculator__top-content">
		<div class="Calculator__form">
			<div class="Calculator__column">
				<div class="CalculatorRowGroup">
					<div class="CalculatorRowGroup__name">Dimensioni dell'ambiente</div>
					<div class="CalculatorRow">
						<div class="CalculatorRow__input-box" style="">
							<div class="CalculatorRow__name CalculatorRow__name--hasHelp" title="Lungimea camerei" style="width: 65px;">Lunghezza</div>
							<input autocomplete="off" aria-label="Lungime" class="CalculatorRow__input" placeholder="" name="length" id="length" type="text" value="5">
						</div>
						<div class="CalculatorRow__unit"><div class="CalculatorRow__select-box">
							<div class="Select CalculatorRow__unit-select has-value Select--single">
								<div class="Select-control">
									<div class="Select-multi-value-wrapper" id="react-select-2--value">
										<select name="length_unit" id="length_unit" class="Select-value">
											<option value="m">m</option>
											<option value="mm">mm</option>
											<option value="cm">cm</option>
											<option value="km">km</option>
											<option value="in">in</option>
											<option value="ft">ft</option>
											<option value="yd">yd</option>
											<option value="mi">mi</option>
											<option value="nmi">nmi</option>
											<option value="fAi">piedi/inchi</option>
											<option value="mAc">metri/centimetri</option>
										</select>
									</div>
								</div>
							</div>
						</div>
					</div>
					<span class="CalculatorRow__autosave-icon"><i class="jsx-2361838830 Icon Icon--base Icon--save"></i></span></button><div class="CalculatorRow__info-box"></div></div>
					<div class="CalculatorRow">
						<div class="CalculatorRow__input-box" style="">
							<div class="CalculatorRow__name CalculatorRow__name--hasHelp" title="Latimea Camerei" style="width: 51px;">Larghezza</div>
								<input autocomplete="off" aria-label="Latime" class="CalculatorRow__input" placeholder="" type="text" id="width" name="width" value="5">
							</div>
							<div class="CalculatorRow__unit">
								<div class="CalculatorRow__select-box">
									<div class="Select CalculatorRow__unit-select has-value Select--single">
										<div class="Select-control">
											<div class="Select-multi-value-wrapper" id="react-select-3--value">
												<select name="width_unit" id="width_unit" class="Select-value">
												<option value="mm">mm</option>
												<option value="m" selected="selected">m</option>
												<option value="km">km</option>
												<option value="in">in</option>
												<option value="ft">ft</option>
												<option value="yd">yd</option>
												<option value="mi">mi</option>
												<option value="nmi">nmi</option>
												<option value="fAi">piedi/pollici</option>
												<option value="mAc">metri/centimetri</option>
												</select>
											</div>
										</div>
									</div>
								</div>
							</div>
							<span class="CalculatorRow__autosave-icon"><i class="jsx-2361838830 Icon Icon--base Icon--save"></i></span></button><div class="CalculatorRow__info-box">
						</div>
					</div>

					<div class="CalculatorRow">
						<div class="CalculatorRow__input-box" style="">
							<div class="CalculatorRow__name CalculatorRow__name--hasHelp" title="Latimea Camerei" style="width: 51px;">altezza</div>
								<input autocomplete="off" aria-label="Latime" class="CalculatorRow__input" placeholder="" type="text" name="height" id="height" value="2.7">
							</div>
							<div class="CalculatorRow__unit">
								<div class="CalculatorRow__select-box">
									<div class="Select CalculatorRow__unit-select has-value Select--single">
										<div class="Select-control">
											<div class="Select-multi-value-wrapper" id="react-select-3--value">
												<select name="height_unit" id="height_unit" class="Select-value">
												<option value="mm">mm</option>
												<option value="m" selected="selected">m</option>
												<option value="km">km</option>
												<option value="in">in</option>
												<option value="ft">ft</option>
												<option value="yd">yd</option>
												<option value="mi">mi</option>
												<option value="nmi">nmi</option>
												<option value="fAi">piedi/pollici</option>
												<option value="mAc">metri/centimetri</option>
												</select>
											</div>
										</div>
									</div>
								</div>
							</div>
							<input type="hidden" name="heigh_U_Val" value="">
							<span class="CalculatorRow__autosave-icon"><i class="jsx-2361838830 Icon Icon--base Icon--save"></i></span></button><div class="CalculatorRow__info-box">
						</div>
					</div>
					<!-- end -->
				</div> <!--one group ends -->
				<!-- new group starts -->
				<div class="CalculatorRowGroup">
					<div class="CalculatorRowGroup__name">Caratteristiche dell'ambiente</div>
					<div class="CalculatorRow">
						<div class="CalculatorRow__input-box" style="">
							<div class="CalculatorRow__name CalculatorRow__name--hasHelp" title="Lungimea camerei" style="width: 65px;">Livello</div>
							<!--<input autocomplete="off" aria-label="Lungime" class="CalculatorRow__input" placeholder="" type="text" value="4"> -->
						</div>
						<div class="CalculatorRow__unit"><div class="CalculatorRow__select-box">
							<div class="Select CalculatorRow__unit-select has-value Select--single">
								<div class="Select-control">
									<div class="Select-multi-value-wrapper" id="react-select-2--value">
										<select name="floor_level" id="floor_level" class="Select-value">
											<option value="ground">Piano terra</option>
											<option value="intermediate" selected="selected">Livello intermedio</option>
											<option value="top">Livello superiore</option>
										</select>
									</div>
								</div>
							</div>
						</div>
					</div>
					<span class="CalculatorRow__autosave-icon"><i class="jsx-2361838830 Icon Icon--base Icon--save"></i></span></button><div class="CalculatorRow__info-box"></div></div>

					<div class="CalculatorRow">
						<div class="CalculatorRow__input-box" style="">
							<div class="CalculatorRow__name CalculatorRow__name--hasHelp" title="Lungimea camerei" style="width: 65px;">Isolamento</div>
							<!--<input autocomplete="off" aria-label="Lungime" class="CalculatorRow__input" placeholder="" type="text" value="4"> -->
						</div>
						<div class="CalculatorRow__unit"><div class="CalculatorRow__select-box">
							<div class="Select CalculatorRow__unit-select has-value Select--single">
								<div class="Select-control">
									<div class="Select-multi-value-wrapper" id="react-select-2--value">
										<select id="insulation_type" class="Select-value">
											<option value="select">select</option>
											<option value="2.2">Nessun altro isolamento</option>
											<option value="1.0" selected="selected">Isolamento moderato</option>
											<option value="0.6">Isolamento molto efficiente</option>
										</select>
									</div>
								</div>
							</div>
						</div>
					</div>
					<span class="CalculatorRow__autosave-icon"><i class="jsx-2361838830 Icon Icon--base Icon--save"></i></span></button><div class="CalculatorRow__info-box"></div></div>

					<div class="CalculatorRow">
						<div class="CalculatorRow__input-box" style="">
							<div class="CalculatorRow__name CalculatorRow__name--hasHelp" title="Lungimea camerei" style="width: 155px;">Numero di pareti esterne</div>
							<!--<input autocomplete="off" aria-label="Lungime" class="CalculatorRow__input" placeholder="" type="text" value="4"> -->
						</div>
						<div class="CalculatorRow__unit"><div class="CalculatorRow__select-box">
							<div class="Select CalculatorRow__unit-select has-value Select--single">
								<div class="Select-control">
									<div class="Select-multi-value-wrapper" id="react-select-2--value">
										<select name="wall_num" id="wall_num" class="Select-value">
											<option value="1">1</option>
											<option value="2">2</option>
											<option value="3">3</option>
											<option value="4" selected="selected">4</option>
										</select>
									</div>
								</div>
							</div>
						</div>
					</div>
					<span class="CalculatorRow__autosave-icon"><i class="jsx-2361838830 Icon Icon--base Icon--save"></i></span></button><div class="CalculatorRow__info-box"></div></div>
				</div><!-- new group ends -->

				<!-- 3rd new group starts -->
				<div class ="advance-setting-area" id="advMode" style="display: none;">
					<div class="CalculatorRowGroup">
						<div class="CalculatorRowGroup__name">Impostazioni avanzate</div>
						<div class="CalculatorRow">
							<div class="CalculatorRow__input-box" style="">
								<div class="CalculatorRow__name CalculatorRow__name--hasHelp" title="Lungimea camerei" style="width: 65px;">valore U</div>
								<input autocomplete="off" aria-label="Lungime" class="CalculatorRow__input" name = "custom_u_value" id="custom_u_value" placeholder="" type="text" value="">
							</div>
							<div class="CalculatorRow__unit"><span class="CalculatorRow__suffix-end">W/(K m²)</span></div>
						</div>
						<span class="CalculatorRow__autosave-icon"><i class="jsx-2361838830 Icon Icon--base Icon--save"></i></span></button><div class="CalculatorRow__info-box"></div>

					<!--	<div class="CalculatorRow">
							<div class="CalculatorRow__input-box" style="">
								<div class="CalculatorRow__name CalculatorRow__name--hasHelp" title="Lungimea camerei" style="width: 155px;">Number of windows</div>
								<input autocomplete="off" aria-label="Lungime" class="CalculatorRow__input" id="Ad_modeWindows" placeholder="" type="text" value="">
							</div>
						</div>
						<span class="CalculatorRow__autosave-icon"><i class="jsx-2361838830 Icon Icon--base Icon--save"></i></span></button><div class="CalculatorRow__info-box"></div>

						<div class="CalculatorRow">
							<div class="CalculatorRow__input-box" style="">
								<div class="CalculatorRow__name CalculatorRow__name--hasHelp" title="Lungimea camerei" style="width: 155px;">Number of doors</div>
								<input autocomplete="off" aria-label="Lungime" class="CalculatorRow__input" id="Ad_modeDoors" placeholder="" type="text" value="">
							</div>
						</div> -->
							<span class="CalculatorRow__autosave-icon"><i class="jsx-2361838830 Icon Icon--base Icon--save"></i></span></button>
							<div class="CalculatorRow__info-box"></div>
						</div><!--3rd new group ends -->
					</div>

					<!-- 4th new group starts -->
					<div class="CalculatorRowGroup">
					<div class="CalculatorRowGroup__name">Temperatura</div>
					<div class="CalculatorRow">
						<div class="CalculatorRow__input-box" style="">
							<div class="CalculatorRow__name CalculatorRow__name--hasHelp" title="Lungimea camerei" style="width: 65px;">Ambiente</div>
							<input autocomplete="off" aria-label="Lungime" class="CalculatorRow__input" placeholder="" type="text" id="ambientTemp" value="-20">
						</div>
						<div class="CalculatorRow__unit"><div class="CalculatorRow__select-box">
							<div class="Select CalculatorRow__unit-select has-value Select--single">
								<div class="Select-control">
									<div class="Select-multi-value-wrapper" id="react-select-2--value">
										<select name="ambientTempUnit" id="ambientTempUnit" class="Select-value">
											<option value="C" selected="selected">°C</option>
											<option value="F">°F</option>
											<option value="K">K</option>
										</select>
									</div>
								</div>
							</div>
						</div>
					</div>
					<span class="CalculatorRow__autosave-icon"><i class="jsx-2361838830 Icon Icon--base Icon--save"></i></span></button><div class="CalculatorRow__info-box"></div></div>

					<div class="CalculatorRow">
						<div class="CalculatorRow__input-box" style="">
							<div class="CalculatorRow__name CalculatorRow__name--hasHelp" title="Lungimea camerei" style="width: 65px;">Interna</div>
							<input autocomplete="off" aria-label="Lungime" class="CalculatorRow__input" placeholder="" type="text" id="internalTemp" value="20">
						</div>
						<div class="CalculatorRow__unit"><div class="CalculatorRow__select-box">
							<div class="Select CalculatorRow__unit-select has-value Select--single">
								<div class="Select-control">
									<div class="Select-multi-value-wrapper" id="react-select-2--value">
										<select name="internalTempUnit" id="internalTempUnit" class="Select-value">
											<option value="C" selected="selected">°C</option>
											<option value="F">°F</option>
											<option value="K">K</option>
										</select>
									</div>
								</div>
							</div>
						</div>
					</div>
					<span class="CalculatorRow__autosave-icon"><i class="jsx-2361838830 Icon Icon--base Icon--save"></i></span></button><div class="CalculatorRow__info-box"></div></div>
				</div><!-- 4th new group ends -->


					<!-- 5th new group starts -->
					<div class="CalculatorRowGroup">
					<div class="CalculatorRowGroup__name">Riscaldamento</div>
					<div class="CalculatorRow">
						<div class="CalculatorRow__input-box" style="">
							<div class="CalculatorRow__name CalculatorRow__name--hasHelp" title="Lungimea camerei" style="width: 65px;">Perdita di calore</div>
							<input autocomplete="off" aria-label="Lungime" class="CalculatorRow__input" placeholder="" type="text" name="heat_loss" id="heat_loss" value="">
						</div>
						<div class="CalculatorRow__unit"><span class="CalculatorRow__suffix">W/K</span></div>
					</div>
					<span class="CalculatorRow__autosave-icon"><i class="jsx-2361838830 Icon Icon--base Icon--save"></i></span></button><div class="CalculatorRow__info-box"></div></div>

					<div class="CalculatorRowGroup">
					<div class="CalculatorRow">
						<div class="CalculatorRow__input-box" style="">
							<div class="CalculatorRow__name CalculatorRow__name--hasHelp" title="Lungimea camerei" style="width: 65px;">Energia necessaria</div>
							<input autocomplete="off" aria-label="Lungime" class="CalculatorRow__input" placeholder="" type="text" name="required_power" id="required_power" value="">
						</div>
						<div class="CalculatorRow__unit"><div class="CalculatorRow__select-box">
							<div class="Select CalculatorRow__unit-select has-value Select--single">
								<div class="Select-control">
									<div class="Select-multi-value-wrapper" id="react-select-2--value">
										<select name="power_unit" id="power_unit" class="Select-value">
											<option value="w">Watt</option>
											<option value="miw">milliwatt</option>
											<option value="kw">kilowatt</option>
											<option value="mw">megawatt</option>
											<option value="gw">gigawatt</option>
											<option value="btu">BTU (Brtish thermal Unit)</option>
											<option value="hp">cavalli vapore macchina</option>
										</select>
									</div>
								</div>
							</div>
						</div>
					</div>
					<span class="CalculatorRow__autosave-icon"><i class="jsx-2361838830 Icon Icon--base Icon--save"></i></span></button><div class="CalculatorRow__info-box"></div></div>
					</div>
				</div><!-- 5th new group ends -->
				<div id="weightgaininfolink"><a href="#" id="cshmore" onclick="cshmoreoption(event);">Advanced setting</a></div>
			</div>
		</div>
	</div>
</div>
<script>
function cshmoreoption(e) {
	e.preventDefault();
	var x = document.getElementById("advMode");
	var settingID = document.getElementById("cshmore");
	if (x.style.display === "none") {
		x.style.display = "block";
		settingID.innerHTML = "Modalità semplice";
		var insulation_typeVal = jQuery('#insulation_type').val();
		jQuery('#custom_u_value').val(insulation_typeVal);
	} else {
		x.style.display = "none";
		settingID.innerHTML = "Setari avansate";
	}

}

function calculateAmbientTempChange(previousVal,ambientVal,ambient_unitVal) {
	//alert("sdnfsdnf");
	if(previousVal == 'C') {
	//	var temp_in_fahrenheit = ambientVal * 33.8;
		//var temp_in_K = (ambientVal) + 273.15;
		var temp_in_K = (parseInt(ambientVal) + 273.15).toFixed(4);
	} else if(previousVal == 'K') {
		//var temp_in_fahrenheit = ambientVal * -457.87;
		var temp_in_K = ambientVal;
	} else if(previousVal == 'F') {
		//var temp_in_fahrenheit = ambientVal * -457.87;
		var temp_in_K = (ambientVal -  32) * 5/9 + 273.15;
	}
	if(ambient_unitVal == 'C') {
		var temp_in_C = temp_in_K  -273.15;
		jQuery ('#ambientTemp').val(Math.round(temp_in_C));
	} if(ambient_unitVal == 'K') {
		//var temp_in_K = temp_in_K * 255.928;
		jQuery ('#ambientTemp').val(temp_in_K);
		//alert(temp_in_K);
	} if(ambient_unitVal == 'F') {
		var temp_in_F = (parseInt(temp_in_K) - 273.15) * 9/5 + 32;
		jQuery ('#ambientTemp').val(Math.round(temp_in_F));
	}
}

 function calculateInternalTempChange(previousVal,internalVal,internal_unitVal) {
	// alert("sdnfsdnf");
	// alert(internalVal);
	if(previousVal == 'C') {
		var temp_in_K = (parseInt(internalVal) + 273.15).toFixed(4);
	} else if(previousVal == 'K') {
		var temp_in_K = internalVal;
	} else if(previousVal == 'F') {
		//var temp_in_K = internalVal - 255.928;
		var temp_in_K = (internalVal -  32) * 5/9 + 273.15;
	}


	if(internal_unitVal == 'C') {
		var temp_in_C = temp_in_K  -273.15;
		jQuery ('#internalTemp').val(Math.round(temp_in_C));
	} if(internal_unitVal == 'K') {
		jQuery ('#internalTemp').val(parseInt(temp_in_K));
	} if(internal_unitVal == 'F') {
		var temp_in_F = (parseInt(temp_in_K) - 273.15) * 9/5 + 32;
		//jQuery ('#internalTemp').val(Math.round(parseInt(temp_in_F)));
		jQuery ('#internalTemp').val(Math.round(temp_in_F));
	}

}

function calculatePowerChange(previousVal,powerVal,power_unitVal) {
	if(previousVal == 'miw') {
		var power_in_watts = powerVal * 0.001;
	}if(previousVal == 'w') {
		var power_in_watts = powerVal;
	}  else if(previousVal == 'kw') {
		var power_in_watts = powerVal * 1000;
	} else if(previousVal == 'mw') {
		var power_in_watts = powerVal * 1000000;
	} else if(previousVal == 'gw') {
		var power_in_watts = powerVal * 1e+9;
	} else if(previousVal == 'btu') {
		var power_in_watts = powerVal * 0.293071;
	} else if(previousVal == 'hp') {
		var power_in_watts = powerVal * 745.699872;
	}

	if(power_unitVal == 'miw') {
		var power_in_miw = power_in_watts * 1000;
		jQuery ('#required_power').val(power_in_miw);
	} else if(power_unitVal == 'kw') {
		var power_in_kw = power_in_watts * 0.001;
		jQuery ('#required_power').val(power_in_kw);
	} else if(power_unitVal == 'w') {
		var power_in_kw = power_in_watts;
		jQuery ('#required_power').val(power_in_kw);
	} else if(power_unitVal == 'mw') {
		var power_in_mw = power_in_watts * 1e-6;
		jQuery ('#required_power').val(power_in_mw);
	} else if(power_unitVal == 'gw') {
		var power_in_gw = power_in_watts * 1e-9;
		jQuery ('#required_power').val(power_in_gw);
	} else if(power_unitVal == 'btu') {
		var power_in_btu = power_in_watts * 3.41;
		jQuery ('#required_power').val(power_in_btu);
	} else if(power_unitVal == 'hp') {
		var power_in_hp = power_in_watts / 745.699872;
		jQuery ('#required_power').val(power_in_hp);
	}

}

function calculateUnitChange(previousVal,lengthVal,length_unitVal) {
	if(previousVal == 'km') {
		var length_in_meter = lengthVal * 1000;
	} else if(previousVal == 'mm') {
		var length_in_meter = lengthVal * 0.001;
	} else if(previousVal == 'm') {
		var length_in_meter = lengthVal;
	} else if(previousVal == 'cm') {
		var length_in_meter = lengthVal * 0.01;
	} else if(previousVal == 'in') {
		var length_in_meter = lengthVal * 0.0254;
	} else if(previousVal == 'ft') {
		var length_in_meter = lengthVal * 0.3048;
	} else if(previousVal == 'yd') {
		var length_in_meter = lengthVal * 0.9144;
	} else if(previousVal == 'mi') {
		var length_in_meter = lengthVal * 1609.34;
	} else if(previousVal == 'nmi') {
		var length_in_meter = lengthVal * 1852;
	} else if(previousVal == 'fAi') {
		var length_in_meter = lengthVal / 3.3;
	} else if(previousVal == 'mAc') {
		var length_in_meter = lengthVal / 100;
	}

		if(length_unitVal == 'mm') {
				var length_in_mm = length_in_meter * 1000;
				jQuery ('#length').val(length_in_mm);

		}
		if(length_unitVal == 'km') {
				var length_in_km = length_in_meter * 0.001;
				jQuery ('#length').val(length_in_km);

		}  else if(length_unitVal == 'm') {

			jQuery ('#length').val(Math.round(length_in_meter));

		}else if(length_unitVal == 'cm') {
			//   var length_in_meter = lengthVal* 1000;
			var length_in_cm = length_in_meter * 100;
			//alert(length_in_meter);
			jQuery ('#length').val(length_in_cm);

		} else if(length_unitVal == 'in') {
		//	var length_in_meter = lengthVal * 1000;
			var length_in_in = length_in_meter * 39.3701;
			jQuery ('#length').val(length_in_in);

		} else if(length_unitVal == 'ft') {
		//	var length_in_meter = lengthVal * 1000;
			var length_in_ft = length_in_meter * 3.280841666667;
			jQuery ('#length').val(Math.round(length_in_ft));

		} else if(length_unitVal == 'yd') {
		//	var length_in_meter = lengthVal * 100;
			var length_in_yd = length_in_meter * 1.09361;
			jQuery ('#length').val(length_in_yd);

		} else if(length_unitVal == 'mi') {
		//	var length_in_meter = lengthVal * 1000;
			var length_in_mi = length_in_meter * 0.000621371;
			var newVal = length_in_mi.toFixed(6);
			jQuery ('#length').val(newVal);

		} else if(length_unitVal == 'nmi') {
		//	var length_in_meter = lengthVal * 1000;
			var length_in_mni = length_in_meter * 0.000539957;
			jQuery ('#length').val(length_in_mni.toFixed(6));

		} else if(length_unitVal == 'fAi') {
		//	var length_in_meter = lengthVal * 1000;
			var length_in_fai = length_in_meter * 3.3;
			jQuery ('#length').val(length_in_fai);

		} else if(length_unitVal == 'mAc') {
		//	var length_in_meter = lengthVal * 1000;
			var length_in_mac = length_in_meter * 100;
			jQuery ('#length').val(length_in_mac);
		}
	}

	/* width */
	function calculateHeightUnitChange(previousVal,lengthVal,length_unitVal) {
	if(previousVal == 'km') {
		var length_in_meter = lengthVal * 1000;
	} else if(previousVal == 'mm') {
		var length_in_meter = lengthVal * 0.001;
	} else if(previousVal == 'm') {
		var length_in_meter = lengthVal;
	} else if(previousVal == 'cm') {
		var length_in_meter = lengthVal * 0.01;
	} else if(previousVal == 'in') {
		var length_in_meter = lengthVal * 0.0254;
	} else if(previousVal == 'ft') {
		var length_in_meter = lengthVal * 0.3048;
	} else if(previousVal == 'yd') {
		var length_in_meter = lengthVal * 0.9144;
	} else if(previousVal == 'mi') {
		var length_in_meter = lengthVal * 1609.34;
	} else if(previousVal == 'nmi') {
		var length_in_meter = lengthVal * 1852;
	} else if(previousVal == 'fAi') {
		var length_in_meter = lengthVal * 0.001;
	} else if(previousVal == 'mAc') {
		var length_in_meter = lengthVal * 0.001;
	}

		if(length_unitVal == 'mm') {
				var length_in_mm = length_in_meter * 1000;
				jQuery ('#height').val(length_in_mm);

		}
		if(length_unitVal == 'km') {
				var length_in_km = length_in_meter * 0.001;
				jQuery ('#height').val(length_in_km);

		}  else if(length_unitVal == 'm') {

			jQuery ('#height').val(length_in_meter);

		}else if(length_unitVal == 'cm') {
			//   var length_in_meter = lengthVal* 1000;
			var length_in_cm = length_in_meter * 100;
			//alert(length_in_meter);
			jQuery ('#height').val(length_in_cm);

		} else if(length_unitVal == 'in') {
		//	var length_in_meter = lengthVal * 1000;
			var length_in_in = length_in_meter * 39.3701;
			jQuery ('#height').val(length_in_in);

		} else if(length_unitVal == 'ft') {
		//	var length_in_meter = lengthVal * 1000;
			var length_in_ft = length_in_meter * 3.280841666667;
			jQuery ('#height').val(length_in_ft);

		} else if(length_unitVal == 'yd') {
		//	var length_in_meter = lengthVal * 1000;
			var length_in_yd = length_in_meter * 1.09361;
			jQuery ('#height').val(length_in_yd);

		} else if(length_unitVal == 'mi') {
		//	var length_in_meter = lengthVal * 1000;
			var length_in_mi = length_in_meter * 0.000621371;
			jQuery ('#height').val(length_in_mi);

		} else if(length_unitVal == 'nmi') {
		//	var length_in_meter = lengthVal * 1000;
			var length_in_mni = length_in_meter *0.00053995709503245226547;
			jQuery ('#height').val(length_in_mni);

		} else if(length_unitVal == 'fAi') {
		//	var length_in_meter = lengthVal * 1000;
			var length_in_fai = length_in_meter * 3.3;
			jQuery ('#height').val(length_in_fai);

		} else if(length_unitVal == 'mAc') {
		//	var length_in_meter = lengthVal * 1000;
			var length_in_mac = length_in_meter * 0.001;
			jQuery ('#height').val(length_in_mac);
		}
	}
	/* height*/
	function calculateWidthUnitChange(previousVal,lengthVal,length_unitVal) {
	if(previousVal == 'km') {
		var length_in_meter = lengthVal * 1000;
	} else if(previousVal == 'mm') {
		var length_in_meter = lengthVal * 0.001;
	} else if(previousVal == 'm') {
		var length_in_meter = lengthVal;
	} else if(previousVal == 'cm') {
		var length_in_meter = lengthVal * 0.01;
	} else if(previousVal == 'in') {
		var length_in_meter = lengthVal * 0.0254;
	} else if(previousVal == 'ft') {
		var length_in_meter = lengthVal * 0.3048;
	} else if(previousVal == 'yd') {
		var length_in_meter = lengthVal * 0.9144;
	} else if(previousVal == 'mi') {
		var length_in_meter = lengthVal * 1609.34;
	} else if(previousVal == 'nmi') {
		var length_in_meter = lengthVal * 1852;
	} else if(previousVal == 'fAi') {
		var length_in_meter = lengthVal * 0.001;
	} else if(previousVal == 'mAc') {
		var length_in_meter = lengthVal * 0.001;
	}

		if(length_unitVal == 'mm') {
				var length_in_mm = length_in_meter * 1000;
				jQuery ('#width').val(length_in_mm);

		}
		if(length_unitVal == 'km') {
				var length_in_km = length_in_meter * 0.001;
				jQuery ('#width').val(length_in_km);

		}  else if(length_unitVal == 'm') {

			jQuery ('#width').val(length_in_meter);

		}else if(length_unitVal == 'cm') {
			//   var length_in_meter = lengthVal* 1000;
			var length_in_cm = length_in_meter * 100;
			//alert(length_in_meter);
			jQuery ('#width').val(length_in_cm);

		} else if(length_unitVal == 'in') {
		//	var length_in_meter = lengthVal * 1000;
			var length_in_in = length_in_meter * 39.3701;
			jQuery ('#width').val(length_in_in);

		} else if(length_unitVal == 'ft') {
		//	var length_in_meter = lengthVal * 1000;
			var length_in_ft = length_in_meter * 3.280841666667;
			jQuery ('#width').val(length_in_ft);

		} else if(length_unitVal == 'yd') {
		//	var length_in_meter = lengthVal * 1000;
			var length_in_yd = length_in_meter * 1.09361;
			jQuery ('#width').val(length_in_yd);

		} else if(length_unitVal == 'mi') {
		//	var length_in_meter = lengthVal * 1000;
			var length_in_mi = length_in_meter * 0.000621371;
			jQuery ('#width').val(length_in_mi);

		} else if(length_unitVal == 'nmi') {
		//	var length_in_meter = lengthVal * 1000;
			var length_in_mni = length_in_meter *0.00053995709503245226547;
			jQuery ('#width').val(length_in_mni);

		} else if(length_unitVal == 'fAi') {
		//	var length_in_meter = lengthVal * 1000;
			var length_in_fai = length_in_meter * 0.001;
			jQuery ('#width').val(length_in_fai);

		} else if(length_unitVal == 'mAc') {
		//	var length_in_meter = lengthVal * 1000;
			var length_in_mac = length_in_meter * 0.001;
			jQuery ('#width').val(length_in_mac);
		}
	}
	jQuery(document).ready(function() {
		(function () {
			$("#insulation_type").change(function() {
				var insulation_typeVal = jQuery('#insulation_type').val();
				jQuery('#custom_u_value').val(insulation_typeVal);
			/*	alert(insulation_typeVal);
				if(parseInt(insulation_typeVal) != parseInt("2.2") || parseInt(insulation_typeVal) != parseInt("1.0") || parseInt(insulation_typeVal) != parseInt("0.6")) {
					alert("if");
					jQuery("#insulation_type").val(jQuery("#insulation_type option:first").val());
				} else {
					alert("else");
				} */
			});

		/*	jQuery("#custom_u_value").on('keyup', function() {
				var custom_u_value = jQuery('#custom_u_value').val();
				alert(custom_u_value);
				if(parseInt(custom_u_value) != 2.2 || parseInt(custom_u_value) != 1.0 || parseInt(custom_u_value) != 1 || parseInt(custom_u_value) != 0.6) {
					//alert("if");
					jQuery("#insulation_type").val(jQuery("#insulation_type option:first").val());
				} else {
					alert("else");
				}
			});
		*/

		})();
		var lengthVal =jQuery ('#length').val();
		var widthVal = jQuery('#width').val();
		var heightVal = jQuery('#height').val();
		var floor_levelVal= jQuery("#floor_level option:selected").val();
		var insulation_typeVal = jQuery('#insulation_type').val();
		var lengthUVal =jQuery ('#length_unit').val();
		var widthUVal =jQuery ('#width_unit').val();
		var heightUVal =jQuery ('#height_unit').val();
		var wall_numVal =jQuery ('#wall_num').val();

		/* Temparature values */
		var ambientTempVal = jQuery ('#ambientTemp').val();
		var ambientTempUnitVal = jQuery ('#ambientTempUnit').val();
		var internalTempVal = jQuery ('#internalTemp').val();
		var internalempUnitVal = jQuery ('#internalTempUnit').val();
		jQuery(function() {
			jQuery.ajax({
				url: admin_ajx_url,
				dataType: 'JSON',
				type: "POST",
				data : {action : 'calculate_heat_ajax',length: lengthVal,width:widthVal,height:heightVal,insulation_type:insulation_typeVal,
					length_unit:lengthUVal,
					width_unit:widthUVal,
					height_unit:heightUVal,
					wall_num:wall_numVal,
					floor_level:floor_levelVal,
					ambientTemp:ambientTempVal,
					ambientTempUnit:ambientTempUnitVal,
					internalTemp:internalTempVal,
					internalTempUnit:internalempUnitVal
				},
				beforeSend: function() {
					//jQuery('#overlay').css("visibility", "visible");
				},
				success: function( response ) {
					//console.log(response['data']['heatLoass']);
					jQuery("#heat_loss").val(response['data']['heatLoass']);
					jQuery("#required_power").val(response['data']['powerRequired']);
				},
				complete: function(){
				}
			})
		})
		// jQuery("#length,#width,#height,#ambientTemp,#internalTemp,#custom_u_value,#Ad_modeWindows,#Ad_modeDoors").on('keyup', function() {
		 jQuery("#length,#width,#height,#ambientTemp,#internalTemp,#custom_u_value").on('keyup', function() {
			var lengthVal =jQuery ('#length').val();
			var widthVal = jQuery('#width').val();
			var heightVal = jQuery('#height').val();
			var custom_u_value = jQuery('#custom_u_value').val();
			var Ad_modeWindows = jQuery('#Ad_modeWindows').val();
			var Ad_modeDoors = jQuery('#Ad_modeDoors').val();
			var floor_levelVal= jQuery("#floor_level option:selected").val();
			var insulation_typeVal = jQuery('#insulation_type').val();
			var lengthUVal =jQuery ('#length_unit').val();
			var widthUVal =jQuery ('#width_unit').val();
			var heightUVal =jQuery ('#height_unit').val();
			var wall_numVal =jQuery ('#wall_num').val();
			/* Temparature values */
			var ambientTempVal = jQuery ('#ambientTemp').val();
			var ambientTempUnitVal = jQuery ('#ambientTempUnit').val();
			var internalTempVal = jQuery ('#internalTemp').val();
			var internalempUnitVal = jQuery ('#internalTempUnit').val();
			// Ajax code //
			jQuery(function() {

				jQuery.ajax({

					url: admin_ajx_url,

					type: "POST",
					dataType: 'JSON',
					data : {action : 'calculate_heat_ajax',length: lengthVal,width:widthVal,height:heightVal,insulation_type:insulation_typeVal,
					length_unit:lengthUVal,
					width_unit:widthUVal,
					height_unit:heightUVal,
					wall_num:wall_numVal,
					floor_level:floor_levelVal,
					ambientTemp:ambientTempVal,
					ambientTempUnit:ambientTempUnitVal,
					internalTemp:internalTempVal,
					internalTempUnit:internalempUnitVal,
					custom_u_valueVal:custom_u_value,
					Ad_modeWindowsVal:Ad_modeWindows,
					Ad_modeDoorsVal:Ad_modeDoors
				},
					beforeSend: function() {
						//jQuery('#overlay').css("visibility", "visible");
					},

					success: function( response ) {
						jQuery("#heat_loss").val(response['data']['heatLoass']);
						jQuery("#required_power").val(response['data']['powerRequired']);
					},

					complete: function(){


					}

				})

			})

			// Ajax code //
		});

		// Onchange Event //
		jQuery('#insulation_type,#floor_level,#wall_num').on('change', function() {
		//jQuery(document).on('change',"#insulation_type","#floor_level",function (e) {
		//jQuery("#cost, #percent").change(function() {
			var insulation_typeVal= jQuery("#insulation_type option:selected").val();
			var floor_levelVal= jQuery("#floor_level option:selected").val();
			var lengthVal =jQuery ('#length').val();
			var widthVal = jQuery('#width').val();
			var heightVal = jQuery('#height').val();
			var custom_u_value = jQuery('#custom_u_value').val();
			var Ad_modeWindows = jQuery('#Ad_modeWindows').val();
			var Ad_modeDoors = jQuery('#Ad_modeDoors').val();
			var lengthUVal =jQuery ('#length_unit').val();
			var widthUVal =jQuery ('#width_unit').val();
			var heightUVal =jQuery ('#height_unit').val();
			var wall_numVal =jQuery ('#wall_num').val();
			/* Temparature values */
			var ambientTempVal = jQuery ('#ambientTemp').val();
			var ambientTempUnitVal = jQuery ('#ambientTempUnit').val();
			var internalTempVal = jQuery ('#internalTemp').val();
			var internalempUnitVal = jQuery ('#internalTempUnit').val();
			// Ajax code //
			jQuery(function() {

				jQuery.ajax({

					url: admin_ajx_url,

					type: "POST",
					dataType: 'JSON',
					data : {action : 'calculate_heat_ajax',length: lengthVal,width:widthVal,height:heightVal,insulation_type:insulation_typeVal,
					length_unit:lengthUVal,
					width_unit:widthUVal,
					height_unit:heightUVal,
					wall_num:wall_numVal,
					floor_level:floor_levelVal,
					ambientTemp:ambientTempVal,
					ambientTempUnit:ambientTempUnitVal,
					internalTemp:internalTempVal,
					internalTempUnit:internalempUnitVal,
					custom_u_valueVal:custom_u_value,
					Ad_modeWindowsVal:Ad_modeWindows,
					Ad_modeDoorsVal:Ad_modeDoors
				},

					beforeSend: function() {
						//jQuery('#overlay').css("visibility", "visible");
					},

					success: function( response ) {
						jQuery("#heat_loss").val(response['data']['heatLoass']);
						jQuery("#required_power").val(response['data']['powerRequired']);

					},

					complete: function(){


					}

				})
			})
			// Ajax code //
		});
		// End Onchange event //

		/* Unit values changes */
	(function () {
		var previousVal;
		var length_unitVal;
		$("#length_unit").on('focus', function () {
			//alert(jQuery(this).children().val());
			 previousVal = this.value;
			 //alert(previousVal);
		}).change(function() {
			//var selectedCountryVal = jQuery(this).children("option:selected").removeAttr("selected");
		//	var selectedCountryVal = jQuery(this).children("option:selected").attr('selected', 'selected');
			length_unitVal = this.value;
		//	console.log(previousVal);
		//	console.log(length_unitVal);
			var lengthVal =jQuery ('#length').val();

			if(previousVal == 'km') {
				calculateUnitChange(previousVal,lengthVal,length_unitVal);
			} else if(previousVal == 'm') {
				calculateUnitChange(previousVal,lengthVal,length_unitVal);

			} else if(previousVal == 'mm') {
				calculateUnitChange(previousVal,lengthVal,length_unitVal);
			} else if(previousVal == 'cm') {
				calculateUnitChange(previousVal,lengthVal,length_unitVal);
			} else if(previousVal == 'in') {
				calculateUnitChange(previousVal,lengthVal,length_unitVal);
			} else if(previousVal == 'ft') {
				calculateUnitChange(previousVal,lengthVal,length_unitVal);
			} else if(previousVal == 'yd') {
				calculateUnitChange(previousVal,lengthVal,length_unitVal);
			} else if(previousVal == 'mi') {
				calculateUnitChange(previousVal,lengthVal,length_unitVal);
			} else if(previousVal == 'nmi') {
				calculateUnitChange(previousVal,lengthVal,length_unitVal);
			} else if(previousVal == 'fAi') {
				calculateUnitChange(previousVal,lengthVal,length_unitVal);
			} else if(previousVal == 'mAc') {
				calculateUnitChange(previousVal,lengthVal,length_unitVal);
			}

			previousVal = this.value;
		});
	})();

	/* Width Onchange */
	(function () {
		var previousVal;
		var length_unitVal;
		$("#width_unit").on('focus', function () {
			//alert(jQuery(this).children().val());
			 previousVal = this.value;
			 //alert(previousVal);
		}).change(function() {
			//var selectedCountryVal = jQuery(this).children("option:selected").removeAttr("selected");
		//	var selectedCountryVal = jQuery(this).children("option:selected").attr('selected', 'selected');
			length_unitVal = this.value;
		//	console.log(previousVal);
		//	console.log(length_unitVal);
			var lengthVal =jQuery ('#width').val();

			if(previousVal == 'km') {
				calculateWidthUnitChange(previousVal,lengthVal,length_unitVal);
			} else if(previousVal == 'm') {
				calculateWidthUnitChange(previousVal,lengthVal,length_unitVal);

			} else if(previousVal == 'mm') {
				calculateWidthUnitChange(previousVal,lengthVal,length_unitVal);
			} else if(previousVal == 'cm') {
				calculateWidthUnitChange(previousVal,lengthVal,length_unitVal);
			} else if(previousVal == 'in') {
				calculateWidthUnitChange(previousVal,lengthVal,length_unitVal);
			} else if(previousVal == 'ft') {
				calculateWidthUnitChange(previousVal,lengthVal,length_unitVal);
			} else if(previousVal == 'yd') {
				calculateWidthUnitChange(previousVal,lengthVal,length_unitVal);
			} else if(previousVal == 'mi') {
				calculateWidthUnitChange(previousVal,lengthVal,length_unitVal);
			} else if(previousVal == 'nmi') {
				calculateWidthUnitChange(previousVal,lengthVal,length_unitVal);
			} else if(previousVal == 'fAi') {
				calculateWidthUnitChange(previousVal,lengthVal,length_unitVal);
			} else if(previousVal == 'mAc') {
				calculateWidthUnitChange(previousVal,lengthVal,length_unitVal);
			}

			previousVal = this.value;
		});
	})();
	/* Width Onchange */

	/* Height Onchange */
	(function () {
		var previousVal;
		var length_unitVal;
		$("#height_unit").on('focus', function () {
			//alert(jQuery(this).children().val());
			 previousVal = this.value;
			 //alert(previousVal);
		}).change(function() {
			//var selectedCountryVal = jQuery(this).children("option:selected").removeAttr("selected");
		//	var selectedCountryVal = jQuery(this).children("option:selected").attr('selected', 'selected');
			length_unitVal = this.value;
		//	console.log(previousVal);
		//	console.log(length_unitVal);
			var lengthVal =jQuery ('#height').val();

			if(previousVal == 'km') {
				calculateHeightUnitChange(previousVal,lengthVal,length_unitVal);
			} else if(previousVal == 'm') {
				calculateHeightUnitChange(previousVal,lengthVal,length_unitVal);

			} else if(previousVal == 'mm') {
				calculateHeightUnitChange(previousVal,lengthVal,length_unitVal);
			} else if(previousVal == 'cm') {
				calculateHeightUnitChange(previousVal,lengthVal,length_unitVal);
			} else if(previousVal == 'in') {
				calculateHeightUnitChange(previousVal,lengthVal,length_unitVal);
			} else if(previousVal == 'ft') {
				calculateHeightUnitChange(previousVal,lengthVal,length_unitVal);
			} else if(previousVal == 'yd') {
				calculateHeightUnitChange(previousVal,lengthVal,length_unitVal);
			} else if(previousVal == 'mi') {
				calculateHeightUnitChange(previousVal,lengthVal,length_unitVal);
			} else if(previousVal == 'nmi') {
				calculateHeightUnitChange(previousVal,lengthVal,length_unitVal);
			} else if(previousVal == 'fAi') {
				calculateHeightUnitChange(previousVal,lengthVal,length_unitVal);
			} else if(previousVal == 'mAc') {
				calculateHeightUnitChange(previousVal,lengthVal,length_unitVal);
			}

			previousVal = this.value;
		});
	})();
	/* Height Onchange */

	/* power units */
	/* Unit values changes */
	(function () {
		var previousVal;
		var power_unitVal;
		$("#power_unit").on('focus', function () {
			//alert(jQuery(this).children().val());
			 previousVal = this.value;
			 //alert(previousVal);
		}).change(function() {
			//var selectedCountryVal = jQuery(this).children("option:selected").removeAttr("selected");
		//	var selectedCountryVal = jQuery(this).children("option:selected").attr('selected', 'selected');
			power_unitVal = this.value;
		//	console.log(previousVal);
		//	console.log(length_unitVal);
			var powerVal =jQuery ('#required_power').val();

			if(previousVal == 'miw') {
				calculatePowerChange(previousVal,powerVal,power_unitVal);
			} else if(previousVal == 'kw') {
				calculatePowerChange(previousVal,powerVal,power_unitVal);
			}else if(previousVal == 'w') {
				calculatePowerChange(previousVal,powerVal,power_unitVal);
			}  else if(previousVal == 'mw') {
				calculatePowerChange(previousVal,powerVal,power_unitVal);
			} else if(previousVal == 'gw') {
				calculatePowerChange(previousVal,powerVal,power_unitVal);
			} else if(previousVal == 'btu') {
				calculatePowerChange(previousVal,powerVal,power_unitVal);
			} else if(previousVal == 'hp') {
				calculatePowerChange(previousVal,powerVal,power_unitVal);
			}

			previousVal = this.value;
		});
	})();
	/* power units */


	/* Ambient Temperature Unit values changes */
	(function () {
		var previousVal;
		var power_unitVal;
		$("#ambientTempUnit").on('focus', function () {
			 previousVal = this.value;
		}).change(function() {
			//alert("mnsmfnsd");
			ambient_unitVal = this.value;
			var ambientVal =jQuery ('#ambientTemp').val();
			if(previousVal == 'C') {
				calculateAmbientTempChange(previousVal,ambientVal,ambient_unitVal);
			} else if(previousVal == 'F') {
				calculateAmbientTempChange(previousVal,ambientVal,ambient_unitVal);
			}else if(previousVal == 'K') {
				calculateAmbientTempChange(previousVal,ambientVal,ambient_unitVal);
			}

			previousVal = this.value;
		});
	})();
	/* Ambient Temperature Unit values changes */

	/* Internal Temperature Unit values changes */
	(function () {
		var previousVal;
		var power_unitVal;
		$("#internalTempUnit").on('focus', function () {
			 previousVal = this.value;
		}).change(function() {
			internal_unitVal = this.value;
			var internalVal =jQuery ('#internalTemp').val();
			if(previousVal == 'C') {
				calculateInternalTempChange(previousVal,internalVal,internal_unitVal);
			} else if(previousVal == 'F') {
				calculateInternalTempChange(previousVal,internalVal,internal_unitVal);
			}else if(previousVal == 'K') {
				calculateInternalTempChange(previousVal,internalVal,internal_unitVal);
			}

			previousVal = this.value;
		});
	})();
	/* Internal Temperature Unit values changes */
});
</script>
<?php
}
// register shortcode
add_shortcode('heat-loss-calculator', 'heat_loss_calculator');

add_action( 'wp_ajax_calculate_heat_ajax', 'calculate_heat_ajax' );

add_action('wp_ajax_nopriv_calculate_heat_ajax', 'calculate_heat_ajax');



function calculate_heat_ajax() {
	$lengthVal = $_POST['length'];
	$widthVal = $_POST['width'];
	$heightVal = $_POST['height'];
	$insulation_typeVal = $_POST['insulation_type'];
	$length_unitVal = $_POST['length_unit'];
	$width_unitVal = $_POST['width_unit'];
	$height_unitVal = $_POST['height_unit'];
	$wall_numVal = $_POST['wall_num'];
	$ambientTempVal = $_POST['ambientTemp'];
	$ambientTempUnitVal = $_POST['ambientTempUnit'];
	$internalempVal = $_POST['internalTemp'];
	$internalempUnitVal = $_POST['internalTempUnit'];
	$floor_level = $_POST['floor_level'];

	$custom_u_value = $_POST['custom_u_valueVal'];
	$Ad_modeWindows = $_POST['Ad_modeWindowsVal'];
	$Ad_modeDoors = $_POST['Ad_modeDoorsVal'];

	//$room_area = areaInMetersSquaure($lengthVal,$length_unitVal,$widthVal,$width_unitVal,$heightVal,$height_unitVal,$wall_numVal,
	//$insulation_typeVal,$floor_level,$custom_u_value,$Ad_modeWindows,$Ad_modeDoors);
//	$heat_loss = $room_area*$insulation_typeVal;

	$heat_loss = totalHeatLoss($lengthVal,$length_unitVal,$widthVal,$width_unitVal,$heightVal,$height_unitVal,$wall_numVal,
	$insulation_typeVal,$floor_level,$custom_u_value,$Ad_modeWindows,$Ad_modeDoors);

	$powerRequired = calculatePower($heat_loss,$ambientTempVal,$ambientTempUnitVal,$internalempVal,$internalempUnitVal);
	//echo $powerRequired;
	$output_data['data'] = array(
		"heatLoass" => $heat_loss,
		"powerRequired" => $powerRequired
		);
	echo json_encode($output_data);
	exit;

}

